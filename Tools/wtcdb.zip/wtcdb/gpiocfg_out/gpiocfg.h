/*
* gpiocfg.h
*
* create on: Tue Nov 29 19:08:56 2016

* Author:gpiocfg tools
*
*/
#ifndef GPIOCFG_H_
#define GPIOCFG_H_
// this file is need for the macro define..
#include 	"tl_gpiodef.h"
/*************************************************
*     gpio config:  BEGIN
*************************************************/
//--------pin PA0: PA0_AS_GPIO, PA0_AS_SWS,--------//
#define		PIN_PA0_FUNC			PA0_AS_SWS
#define		PIN_PA0_OE			ENABLE


//--------pin PA1: PA1_AS_GPIO,--------//
#define		PIN_PA1_FUNC			NDF
#define		PIN_PA1_OE			ENABLE


//--------pin PA2: PA2_AS_GPIO, PA2_AS_MSDI,--------//
#define		PIN_PA2_FUNC			PA2_AS_GPIO
#define		PIN_PA2_OE			DISABLE
#define		PIN_PA2_IE			ENABLE
#define		PIN_PA2_DS			ENABLE
#define		PIN_PA2_DO			1


//--------pin PA3: PA3_AS_GPIO, PA3_AS_MCLK,--------//
#define		PIN_PA3_FUNC			PA3_AS_GPIO
#define		PIN_PA3_OE			DISABLE
#define		PIN_PA3_IE			ENABLE
#define		PIN_PA3_DS			ENABLE
#define		PIN_PA3_DO			1


//--------pin PA4: PA4_AS_GPIO,--------//
#define		PIN_PA4_FUNC			NDF
#define		PIN_PA4_OE			ENABLE


//--------pin PA5: PA5_AS_GPIO,--------//
#define		PIN_PA5_FUNC			NDF
#define		PIN_PA5_OE			ENABLE


//--------pin PA6: PA6_AS_GPIO,--------//
#define		PIN_PA6_FUNC			PA6_AS_GPIO
#define		PIN_PA6_OE			DISABLE
#define		PIN_PA6_IE			ENABLE
#define		PIN_PA6_DS			ENABLE
#define		PIN_PA6_DO			1


//--------pin PA7: PA7_AS_GPIO,--------//
#define		PIN_PA7_FUNC			PA7_AS_GPIO
#define		PIN_PA7_OE			DISABLE
#define		PIN_PA7_IE			ENABLE
#define		PIN_PA7_DS			ENABLE
#define		PIN_PA7_DO			1


//--------pin PB0: PB0_AS_GPIO,--------//
#define		PIN_PB0_FUNC			NDF
#define		PIN_PB0_OE			ENABLE


//--------pin PB1: PB1_AS_GPIO,--------//
#define		PIN_PB1_FUNC			NDF
#define		PIN_PB1_OE			ENABLE


//--------pin PB2: PB2_AS_GPIO, PB2_AS_MSDO,--------//
#define		PIN_PB2_FUNC			PB2_AS_GPIO
#define		PIN_PB2_OE			DISABLE
#define		PIN_PB2_IE			ENABLE
#define		PIN_PB2_DS			ENABLE
#define		PIN_PB2_DO			1


//--------pin PB3: PB3_AS_GPIO, PB3_AS_MSCN,--------//
#define		PIN_PB3_FUNC			PB3_AS_GPIO
#define		PIN_PB3_OE			DISABLE
#define		PIN_PB3_IE			ENABLE
#define		PIN_PB3_DS			ENABLE
#define		PIN_PB3_DO			1


//--------pin PB4: PB4_AS_GPIO,--------//
#define		PIN_PB4_FUNC			NDF
#define		PIN_PB4_OE			ENABLE


//--------pin PB5: PB5_AS_GPIO, PB5_AS_DM,--------//
#define		PIN_PB5_FUNC			PB5_AS_DM
#define		PIN_PB5_OE			ENABLE


//--------pin PB6: PB6_AS_GPIO, PB6_AS_DP,--------//
#define		PIN_PB6_FUNC			PB6_AS_GPIO
#define		PIN_PB6_OE			DISABLE
#define		PIN_PB6_IE			ENABLE
#define		PIN_PB6_DS			ENABLE
#define		PIN_PB6_DO			1


//--------pin PB7: PB7_AS_GPIO,--------//
#define		PIN_PB7_FUNC			PB7_AS_GPIO
#define		PIN_PB7_OE			DISABLE
#define		PIN_PB7_IE			ENABLE
#define		PIN_PB7_DS			ENABLE
#define		PIN_PB7_DO			1


//--------pin PC0: PC0_AS_GPIO,--------//
#define		PIN_PC0_FUNC			PC0_AS_GPIO
#define		PIN_PC0_OE			ENABLE


//--------pin PC1: PC1_AS_GPIO,--------//
#define		PIN_PC1_FUNC			PC1_AS_GPIO
#define		PIN_PC1_OE			ENABLE


//--------pin PC2: PC2_AS_GPIO,--------//
#define		PIN_PC2_FUNC			PC2_AS_GPIO
#define		PIN_PC2_OE			DISABLE
#define		PIN_PC2_IE			ENABLE
#define		PIN_PC2_DS			ENABLE
#define		PIN_PC2_DO			1


//--------pin PC3: PC3_AS_GPIO,--------//
#define		PIN_PC3_FUNC			PC3_AS_GPIO
#define		PIN_PC3_OE			DISABLE
#define		PIN_PC3_IE			ENABLE
#define		PIN_PC3_DS			ENABLE
#define		PIN_PC3_DO			1


//--------pin PC4: PC4_AS_GPIO,--------//
#define		PIN_PC4_FUNC			NDF
#define		PIN_PC4_OE			ENABLE


//--------pin PC5: PC5_AS_GPIO,--------//
#define		PIN_PC5_FUNC			NDF
#define		PIN_PC5_OE			ENABLE


//--------pin PC6: PC6_AS_GPIO,--------//
#define		PIN_PC6_FUNC			PC6_AS_GPIO
#define		PIN_PC6_OE			DISABLE
#define		PIN_PC6_IE			ENABLE
#define		PIN_PC6_DS			ENABLE
#define		PIN_PC6_DO			1


//--------pin PC7: PC7_AS_GPIO,--------//
#define		PIN_PC7_FUNC			PC7_AS_GPIO
#define		PIN_PC7_OE			DISABLE
#define		PIN_PC7_IE			ENABLE
#define		PIN_PC7_DS			ENABLE
#define		PIN_PC7_DO			1


//--------pin PD0: PD0_AS_GPIO,--------//
#define		PIN_PD0_FUNC			NDF
#define		PIN_PD0_OE			ENABLE


//--------pin PD1: PD1_AS_GPIO,--------//
#define		PIN_PD1_FUNC			NDF
#define		PIN_PD1_OE			ENABLE


//--------pin PD2: PD2_AS_GPIO,--------//
#define		PIN_PD2_FUNC			PD2_AS_GPIO
#define		PIN_PD2_OE			DISABLE
#define		PIN_PD2_IE			ENABLE
#define		PIN_PD2_DS			ENABLE
#define		PIN_PD2_DO			1


//--------pin PD3: PD3_AS_GPIO,--------//
#define		PIN_PD3_FUNC			PD3_AS_GPIO
#define		PIN_PD3_OE			DISABLE
#define		PIN_PD3_IE			ENABLE
#define		PIN_PD3_DS			ENABLE
#define		PIN_PD3_DO			1


//--------pin PD4: PD4_AS_GPIO,--------//
#define		PIN_PD4_FUNC			NDF
#define		PIN_PD4_OE			ENABLE


//--------pin PD5: PD5_AS_GPIO,--------//
#define		PIN_PD5_FUNC			NDF
#define		PIN_PD5_OE			ENABLE


//--------pin PD6: PD6_AS_GPIO,--------//
#define		PIN_PD6_FUNC			PD6_AS_GPIO
#define		PIN_PD6_OE			DISABLE
#define		PIN_PD6_IE			ENABLE
#define		PIN_PD6_DS			ENABLE
#define		PIN_PD6_DO			1


//--------pin PD7: PD7_AS_GPIO,--------//
#define		PIN_PD7_FUNC			PD7_AS_GPIO
#define		PIN_PD7_OE			DISABLE
#define		PIN_PD7_IE			ENABLE
#define		PIN_PD7_DS			ENABLE
#define		PIN_PD7_DO			1


//--------pin PE0: PE0_AS_GPIO,--------//
#define		PIN_PE0_FUNC			NDF
#define		PIN_PE0_OE			ENABLE


//--------pin PE1: PE1_AS_GPIO,--------//
#define		PIN_PE1_FUNC			NDF
#define		PIN_PE1_OE			ENABLE


//--------pin PE2: PE2_AS_GPIO,--------//
#define		PIN_PE2_FUNC			PE2_AS_GPIO
#define		PIN_PE2_OE			DISABLE
#define		PIN_PE2_IE			ENABLE
#define		PIN_PE2_DS			ENABLE
#define		PIN_PE2_DO			1


//--------pin PE3: PE3_AS_GPIO,--------//
#define		PIN_PE3_FUNC			PE3_AS_GPIO
#define		PIN_PE3_OE			DISABLE
#define		PIN_PE3_IE			ENABLE
#define		PIN_PE3_DS			ENABLE
#define		PIN_PE3_DO			1


//--------pin PE4: PE4_AS_GPIO,--------//
#define		PIN_PE4_FUNC			NDF
#define		PIN_PE4_OE			ENABLE


//--------pin PE5: PE5_AS_GPIO,--------//
#define		PIN_PE5_FUNC			NDF
#define		PIN_PE5_OE			ENABLE


//--------pin PE6: PE6_AS_GPIO, PE6_AS_CN,--------//
#define		PIN_PE6_FUNC			PE6_AS_GPIO
#define		PIN_PE6_OE			DISABLE
#define		PIN_PE6_IE			ENABLE
#define		PIN_PE6_DS			ENABLE
#define		PIN_PE6_DO			1


//--------pin PE7: PE7_AS_GPIO,--------//
#define		PIN_PE7_FUNC			PE7_AS_GPIO
#define		PIN_PE7_OE			DISABLE
#define		PIN_PE7_IE			ENABLE
#define		PIN_PE7_DS			ENABLE
#define		PIN_PE7_DO			1


//--------pin PF0: PF0_AS_GPIO, PF0_AS_DO,--------//
#define		PIN_PF0_FUNC			PF0_AS_DO
#define		PIN_PF0_OE			ENABLE


//--------pin PF1: PF1_AS_GPIO, PF1_AS_CK,--------//
#define		PIN_PF1_FUNC			PF1_AS_CK
#define		PIN_PF1_OE			ENABLE




/*************************************************
*     gpio config:  BEGIN
*************************************************/
//this file is need for the gpio_init() macro..
#include	"tl_gpio.h"


#endif
