/*
* tl_gpio.h
*
* create on: Tue Nov 29 19:08:56 2016

* Author:gpiocfg tools
*
*/
#ifndef TL_GPIO_H_
#define TL_GPIO_H_
//-------- pin PA0 config ------//
#ifdef	PIN_PA0_FUNC
	#if(PIN_PA0_FUNC == PA0_AS_GPIO)
		#define	RIO_0586_0		1
	#else
		#define	RIO_0586_0		0
	#endif
#endif


#ifdef	PIN_PA0_OE
	#if(PIN_PA0_OE == ENABLE)
		#define	RIO_0582_0		0
	#else
		#define	RIO_0582_0		1
	#endif
#endif


#ifdef	PIN_PA0_IE
	#if(PIN_PA0_IE == ENABLE)
		#define	RIO_0581_0		1
	#else
		#define	RIO_0581_0		0
	#endif
#endif


#ifdef	PIN_PA0_DS
	#if(PIN_PA0_DS == ENABLE)
		#define	RIO_0585_0		1
	#else
		#define	RIO_0585_0		0
	#endif
#endif


#define	RIO_0583_0		PIN_PA0_DO


//-------- pin PA1 config ------//
#ifdef	PIN_PA1_FUNC
	#if(PIN_PA1_FUNC == PA1_AS_GPIO)
		#define	RIO_0586_1		1
	#endif
#endif


#ifdef	PIN_PA1_OE
	#if(PIN_PA1_OE == ENABLE)
		#define	RIO_0582_1		0
	#else
		#define	RIO_0582_1		1
	#endif
#endif


#ifdef	PIN_PA1_IE
	#if(PIN_PA1_IE == ENABLE)
		#define	RIO_0581_1		1
	#else
		#define	RIO_0581_1		0
	#endif
#endif


#ifdef	PIN_PA1_DS
	#if(PIN_PA1_DS == ENABLE)
		#define	RIO_0585_1		1
	#else
		#define	RIO_0585_1		0
	#endif
#endif


#define	RIO_0583_1		PIN_PA1_DO


//-------- pin PA2 config ------//
#ifdef	PIN_PA2_FUNC
	#if(PIN_PA2_FUNC == PA2_AS_GPIO)
		#define	RIO_0586_2		1
	#else
		#define	RIO_0586_2		0
	#endif
#endif


#ifdef	PIN_PA2_OE
	#if(PIN_PA2_OE == ENABLE)
		#define	RIO_0582_2		0
	#else
		#define	RIO_0582_2		1
	#endif
#endif


#ifdef	PIN_PA2_IE
	#if(PIN_PA2_IE == ENABLE)
		#define	RIO_0581_2		1
	#else
		#define	RIO_0581_2		0
	#endif
#endif


#ifdef	PIN_PA2_DS
	#if(PIN_PA2_DS == ENABLE)
		#define	RIO_0585_2		1
	#else
		#define	RIO_0585_2		0
	#endif
#endif


#define	RIO_0583_2		PIN_PA2_DO


//-------- pin PA3 config ------//
#ifdef	PIN_PA3_FUNC
	#if(PIN_PA3_FUNC == PA3_AS_GPIO)
		#define	RIO_0586_3		1
	#else
		#define	RIO_0586_3		0
	#endif
#endif


#ifdef	PIN_PA3_OE
	#if(PIN_PA3_OE == ENABLE)
		#define	RIO_0582_3		0
	#else
		#define	RIO_0582_3		1
	#endif
#endif


#ifdef	PIN_PA3_IE
	#if(PIN_PA3_IE == ENABLE)
		#define	RIO_0581_3		1
	#else
		#define	RIO_0581_3		0
	#endif
#endif


#ifdef	PIN_PA3_DS
	#if(PIN_PA3_DS == ENABLE)
		#define	RIO_0585_3		1
	#else
		#define	RIO_0585_3		0
	#endif
#endif


#define	RIO_0583_3		PIN_PA3_DO


//-------- pin PA4 config ------//
#ifdef	PIN_PA4_FUNC
	#if(PIN_PA4_FUNC == PA4_AS_GPIO)
		#define	RIO_0586_4		1
	#endif
#endif


#ifdef	PIN_PA4_OE
	#if(PIN_PA4_OE == ENABLE)
		#define	RIO_0582_4		0
	#else
		#define	RIO_0582_4		1
	#endif
#endif


#ifdef	PIN_PA4_IE
	#if(PIN_PA4_IE == ENABLE)
		#define	RIO_0581_4		1
	#else
		#define	RIO_0581_4		0
	#endif
#endif


#ifdef	PIN_PA4_DS
	#if(PIN_PA4_DS == ENABLE)
		#define	RIO_0585_4		1
	#else
		#define	RIO_0585_4		0
	#endif
#endif


#define	RIO_0583_4		PIN_PA4_DO


//-------- pin PA5 config ------//
#ifdef	PIN_PA5_FUNC
	#if(PIN_PA5_FUNC == PA5_AS_GPIO)
		#define	RIO_0586_5		1
	#endif
#endif


#ifdef	PIN_PA5_OE
	#if(PIN_PA5_OE == ENABLE)
		#define	RIO_0582_5		0
	#else
		#define	RIO_0582_5		1
	#endif
#endif


#ifdef	PIN_PA5_IE
	#if(PIN_PA5_IE == ENABLE)
		#define	RIO_0581_5		1
	#else
		#define	RIO_0581_5		0
	#endif
#endif


#ifdef	PIN_PA5_DS
	#if(PIN_PA5_DS == ENABLE)
		#define	RIO_0585_5		1
	#else
		#define	RIO_0585_5		0
	#endif
#endif


#define	RIO_0583_5		PIN_PA5_DO


//-------- pin PA6 config ------//
#ifdef	PIN_PA6_FUNC
	#if(PIN_PA6_FUNC == PA6_AS_GPIO)
		#define	RIO_0586_6		1
	#endif
#endif


#ifdef	PIN_PA6_OE
	#if(PIN_PA6_OE == ENABLE)
		#define	RIO_0582_6		0
	#else
		#define	RIO_0582_6		1
	#endif
#endif


#ifdef	PIN_PA6_IE
	#if(PIN_PA6_IE == ENABLE)
		#define	RIO_0581_6		1
	#else
		#define	RIO_0581_6		0
	#endif
#endif


#ifdef	PIN_PA6_DS
	#if(PIN_PA6_DS == ENABLE)
		#define	RIO_0585_6		1
	#else
		#define	RIO_0585_6		0
	#endif
#endif


#define	RIO_0583_6		PIN_PA6_DO


//-------- pin PA7 config ------//
#ifdef	PIN_PA7_FUNC
	#if(PIN_PA7_FUNC == PA7_AS_GPIO)
		#define	RIO_0586_7		1
	#endif
#endif


#ifdef	PIN_PA7_OE
	#if(PIN_PA7_OE == ENABLE)
		#define	RIO_0582_7		0
	#else
		#define	RIO_0582_7		1
	#endif
#endif


#ifdef	PIN_PA7_IE
	#if(PIN_PA7_IE == ENABLE)
		#define	RIO_0581_7		1
	#else
		#define	RIO_0581_7		0
	#endif
#endif


#ifdef	PIN_PA7_DS
	#if(PIN_PA7_DS == ENABLE)
		#define	RIO_0585_7		1
	#else
		#define	RIO_0585_7		0
	#endif
#endif


#define	RIO_0583_7		PIN_PA7_DO


//-------- pin PB0 config ------//
#ifdef	PIN_PB0_FUNC
	#if(PIN_PB0_FUNC == PB0_AS_GPIO)
		#define	RIO_058e_0		1
	#endif
#endif


#ifdef	PIN_PB0_OE
	#if(PIN_PB0_OE == ENABLE)
		#define	RIO_058a_0		0
	#else
		#define	RIO_058a_0		1
	#endif
#endif


#ifdef	PIN_PB0_IE
	#if(PIN_PB0_IE == ENABLE)
		#define	RIO_0589_0		1
	#else
		#define	RIO_0589_0		0
	#endif
#endif


#ifdef	PIN_PB0_DS
	#if(PIN_PB0_DS == ENABLE)
		#define	RIO_058d_0		1
	#else
		#define	RIO_058d_0		0
	#endif
#endif


#define	RIO_058b_0		PIN_PB0_DO


//-------- pin PB1 config ------//
#ifdef	PIN_PB1_FUNC
	#if(PIN_PB1_FUNC == PB1_AS_GPIO)
		#define	RIO_058e_1		1
	#endif
#endif


#ifdef	PIN_PB1_OE
	#if(PIN_PB1_OE == ENABLE)
		#define	RIO_058a_1		0
	#else
		#define	RIO_058a_1		1
	#endif
#endif


#ifdef	PIN_PB1_IE
	#if(PIN_PB1_IE == ENABLE)
		#define	RIO_0589_1		1
	#else
		#define	RIO_0589_1		0
	#endif
#endif


#ifdef	PIN_PB1_DS
	#if(PIN_PB1_DS == ENABLE)
		#define	RIO_058d_1		1
	#else
		#define	RIO_058d_1		0
	#endif
#endif


#define	RIO_058b_1		PIN_PB1_DO


//-------- pin PB2 config ------//
#ifdef	PIN_PB2_FUNC
	#if(PIN_PB2_FUNC == PB2_AS_GPIO)
		#define	RIO_058e_2		1
	#else
		#define	RIO_058e_2		0
	#endif
#endif


#ifdef	PIN_PB2_OE
	#if(PIN_PB2_OE == ENABLE)
		#define	RIO_058a_2		0
	#else
		#define	RIO_058a_2		1
	#endif
#endif


#ifdef	PIN_PB2_IE
	#if(PIN_PB2_IE == ENABLE)
		#define	RIO_0589_2		1
	#else
		#define	RIO_0589_2		0
	#endif
#endif


#ifdef	PIN_PB2_DS
	#if(PIN_PB2_DS == ENABLE)
		#define	RIO_058d_2		1
	#else
		#define	RIO_058d_2		0
	#endif
#endif


#define	RIO_058b_2		PIN_PB2_DO


//-------- pin PB3 config ------//
#ifdef	PIN_PB3_FUNC
	#if(PIN_PB3_FUNC == PB3_AS_GPIO)
		#define	RIO_058e_3		1
	#else
		#define	RIO_058e_3		0
	#endif
#endif


#ifdef	PIN_PB3_OE
	#if(PIN_PB3_OE == ENABLE)
		#define	RIO_058a_3		0
	#else
		#define	RIO_058a_3		1
	#endif
#endif


#ifdef	PIN_PB3_IE
	#if(PIN_PB3_IE == ENABLE)
		#define	RIO_0589_3		1
	#else
		#define	RIO_0589_3		0
	#endif
#endif


#ifdef	PIN_PB3_DS
	#if(PIN_PB3_DS == ENABLE)
		#define	RIO_058d_3		1
	#else
		#define	RIO_058d_3		0
	#endif
#endif


#define	RIO_058b_3		PIN_PB3_DO


//-------- pin PB4 config ------//
#ifdef	PIN_PB4_FUNC
	#if(PIN_PB4_FUNC == PB4_AS_GPIO)
		#define	RIO_058e_4		1
	#endif
#endif


#ifdef	PIN_PB4_OE
	#if(PIN_PB4_OE == ENABLE)
		#define	RIO_058a_4		0
	#else
		#define	RIO_058a_4		1
	#endif
#endif


#ifdef	PIN_PB4_IE
	#if(PIN_PB4_IE == ENABLE)
		#define	RIO_0589_4		1
	#else
		#define	RIO_0589_4		0
	#endif
#endif


#ifdef	PIN_PB4_DS
	#if(PIN_PB4_DS == ENABLE)
		#define	RIO_058d_4		1
	#else
		#define	RIO_058d_4		0
	#endif
#endif


#define	RIO_058b_4		PIN_PB4_DO


//-------- pin PB5 config ------//
#ifdef	PIN_PB5_FUNC
	#if(PIN_PB5_FUNC == PB5_AS_GPIO)
		#define	RIO_058e_5		1
	#else
		#define	RIO_058e_5		0
	#endif
#endif


#ifdef	PIN_PB5_OE
	#if(PIN_PB5_OE == ENABLE)
		#define	RIO_058a_5		0
	#else
		#define	RIO_058a_5		1
	#endif
#endif


#ifdef	PIN_PB5_IE
	#if(PIN_PB5_IE == ENABLE)
		#define	RIO_0589_5		1
	#else
		#define	RIO_0589_5		0
	#endif
#endif


#ifdef	PIN_PB5_DS
	#if(PIN_PB5_DS == ENABLE)
		#define	RIO_058d_5		1
	#else
		#define	RIO_058d_5		0
	#endif
#endif


#define	RIO_058b_5		PIN_PB5_DO


//-------- pin PB6 config ------//
#ifdef	PIN_PB6_FUNC
	#if(PIN_PB6_FUNC == PB6_AS_GPIO)
		#define	RIO_058e_6		1
	#else
		#define	RIO_058e_6		0
	#endif
#endif


#ifdef	PIN_PB6_OE
	#if(PIN_PB6_OE == ENABLE)
		#define	RIO_058a_6		0
	#else
		#define	RIO_058a_6		1
	#endif
#endif


#ifdef	PIN_PB6_IE
	#if(PIN_PB6_IE == ENABLE)
		#define	RIO_0589_6		1
	#else
		#define	RIO_0589_6		0
	#endif
#endif


#ifdef	PIN_PB6_DS
	#if(PIN_PB6_DS == ENABLE)
		#define	RIO_058d_6		1
	#else
		#define	RIO_058d_6		0
	#endif
#endif


#define	RIO_058b_6		PIN_PB6_DO


//-------- pin PB7 config ------//
#ifdef	PIN_PB7_FUNC
	#if(PIN_PB7_FUNC == PB7_AS_GPIO)
		#define	RIO_058e_7		1
	#endif
#endif


#ifdef	PIN_PB7_OE
	#if(PIN_PB7_OE == ENABLE)
		#define	RIO_058a_7		0
	#else
		#define	RIO_058a_7		1
	#endif
#endif


#ifdef	PIN_PB7_IE
	#if(PIN_PB7_IE == ENABLE)
		#define	RIO_0589_7		1
	#else
		#define	RIO_0589_7		0
	#endif
#endif


#ifdef	PIN_PB7_DS
	#if(PIN_PB7_DS == ENABLE)
		#define	RIO_058d_7		1
	#else
		#define	RIO_058d_7		0
	#endif
#endif


#define	RIO_058b_7		PIN_PB7_DO


//-------- pin PC0 config ------//
#ifdef	PIN_PC0_FUNC
	#if(PIN_PC0_FUNC == PC0_AS_GPIO)
		#define	RIO_0596_0		1
	#endif
#endif


#ifdef	PIN_PC0_OE
	#if(PIN_PC0_OE == ENABLE)
		#define	RIO_0592_0		0
	#else
		#define	RIO_0592_0		1
	#endif
#endif


#ifdef	PIN_PC0_IE
	#if(PIN_PC0_IE == ENABLE)
		#define	RIO_0591_0		1
	#else
		#define	RIO_0591_0		0
	#endif
#endif


#ifdef	PIN_PC0_DS
	#if(PIN_PC0_DS == ENABLE)
		#define	RIO_0595_0		1
	#else
		#define	RIO_0595_0		0
	#endif
#endif


#define	RIO_0593_0		PIN_PC0_DO


//-------- pin PC1 config ------//
#ifdef	PIN_PC1_FUNC
	#if(PIN_PC1_FUNC == PC1_AS_GPIO)
		#define	RIO_0596_1		1
	#endif
#endif


#ifdef	PIN_PC1_OE
	#if(PIN_PC1_OE == ENABLE)
		#define	RIO_0592_1		0
	#else
		#define	RIO_0592_1		1
	#endif
#endif


#ifdef	PIN_PC1_IE
	#if(PIN_PC1_IE == ENABLE)
		#define	RIO_0591_1		1
	#else
		#define	RIO_0591_1		0
	#endif
#endif


#ifdef	PIN_PC1_DS
	#if(PIN_PC1_DS == ENABLE)
		#define	RIO_0595_1		1
	#else
		#define	RIO_0595_1		0
	#endif
#endif


#define	RIO_0593_1		PIN_PC1_DO


//-------- pin PC2 config ------//
#ifdef	PIN_PC2_FUNC
	#if(PIN_PC2_FUNC == PC2_AS_GPIO)
		#define	RIO_0596_2		1
	#endif
#endif


#ifdef	PIN_PC2_OE
	#if(PIN_PC2_OE == ENABLE)
		#define	RIO_0592_2		0
	#else
		#define	RIO_0592_2		1
	#endif
#endif


#ifdef	PIN_PC2_IE
	#if(PIN_PC2_IE == ENABLE)
		#define	RIO_0591_2		1
	#else
		#define	RIO_0591_2		0
	#endif
#endif


#ifdef	PIN_PC2_DS
	#if(PIN_PC2_DS == ENABLE)
		#define	RIO_0595_2		1
	#else
		#define	RIO_0595_2		0
	#endif
#endif


#define	RIO_0593_2		PIN_PC2_DO


//-------- pin PC3 config ------//
#ifdef	PIN_PC3_FUNC
	#if(PIN_PC3_FUNC == PC3_AS_GPIO)
		#define	RIO_0596_3		1
	#endif
#endif


#ifdef	PIN_PC3_OE
	#if(PIN_PC3_OE == ENABLE)
		#define	RIO_0592_3		0
	#else
		#define	RIO_0592_3		1
	#endif
#endif


#ifdef	PIN_PC3_IE
	#if(PIN_PC3_IE == ENABLE)
		#define	RIO_0591_3		1
	#else
		#define	RIO_0591_3		0
	#endif
#endif


#ifdef	PIN_PC3_DS
	#if(PIN_PC3_DS == ENABLE)
		#define	RIO_0595_3		1
	#else
		#define	RIO_0595_3		0
	#endif
#endif


#define	RIO_0593_3		PIN_PC3_DO


//-------- pin PC4 config ------//
#ifdef	PIN_PC4_FUNC
	#if(PIN_PC4_FUNC == PC4_AS_GPIO)
		#define	RIO_0596_4		1
	#endif
#endif


#ifdef	PIN_PC4_OE
	#if(PIN_PC4_OE == ENABLE)
		#define	RIO_0592_4		0
	#else
		#define	RIO_0592_4		1
	#endif
#endif


#ifdef	PIN_PC4_IE
	#if(PIN_PC4_IE == ENABLE)
		#define	RIO_0591_4		1
	#else
		#define	RIO_0591_4		0
	#endif
#endif


#ifdef	PIN_PC4_DS
	#if(PIN_PC4_DS == ENABLE)
		#define	RIO_0595_4		1
	#else
		#define	RIO_0595_4		0
	#endif
#endif


#define	RIO_0593_4		PIN_PC4_DO


//-------- pin PC5 config ------//
#ifdef	PIN_PC5_FUNC
	#if(PIN_PC5_FUNC == PC5_AS_GPIO)
		#define	RIO_0596_5		1
	#endif
#endif


#ifdef	PIN_PC5_OE
	#if(PIN_PC5_OE == ENABLE)
		#define	RIO_0592_5		0
	#else
		#define	RIO_0592_5		1
	#endif
#endif


#ifdef	PIN_PC5_IE
	#if(PIN_PC5_IE == ENABLE)
		#define	RIO_0591_5		1
	#else
		#define	RIO_0591_5		0
	#endif
#endif


#ifdef	PIN_PC5_DS
	#if(PIN_PC5_DS == ENABLE)
		#define	RIO_0595_5		1
	#else
		#define	RIO_0595_5		0
	#endif
#endif


#define	RIO_0593_5		PIN_PC5_DO


//-------- pin PC6 config ------//
#ifdef	PIN_PC6_FUNC
	#if(PIN_PC6_FUNC == PC6_AS_GPIO)
		#define	RIO_0596_6		1
	#endif
#endif


#ifdef	PIN_PC6_OE
	#if(PIN_PC6_OE == ENABLE)
		#define	RIO_0592_6		0
	#else
		#define	RIO_0592_6		1
	#endif
#endif


#ifdef	PIN_PC6_IE
	#if(PIN_PC6_IE == ENABLE)
		#define	RIO_0591_6		1
	#else
		#define	RIO_0591_6		0
	#endif
#endif


#ifdef	PIN_PC6_DS
	#if(PIN_PC6_DS == ENABLE)
		#define	RIO_0595_6		1
	#else
		#define	RIO_0595_6		0
	#endif
#endif


#define	RIO_0593_6		PIN_PC6_DO


//-------- pin PC7 config ------//
#ifdef	PIN_PC7_FUNC
	#if(PIN_PC7_FUNC == PC7_AS_GPIO)
		#define	RIO_0596_7		1
	#endif
#endif


#ifdef	PIN_PC7_OE
	#if(PIN_PC7_OE == ENABLE)
		#define	RIO_0592_7		0
	#else
		#define	RIO_0592_7		1
	#endif
#endif


#ifdef	PIN_PC7_IE
	#if(PIN_PC7_IE == ENABLE)
		#define	RIO_0591_7		1
	#else
		#define	RIO_0591_7		0
	#endif
#endif


#ifdef	PIN_PC7_DS
	#if(PIN_PC7_DS == ENABLE)
		#define	RIO_0595_7		1
	#else
		#define	RIO_0595_7		0
	#endif
#endif


#define	RIO_0593_7		PIN_PC7_DO


//-------- pin PD0 config ------//
#ifdef	PIN_PD0_FUNC
	#if(PIN_PD0_FUNC == PD0_AS_GPIO)
		#define	RIO_059e_0		1
	#endif
#endif


#ifdef	PIN_PD0_OE
	#if(PIN_PD0_OE == ENABLE)
		#define	RIO_059a_0		0
	#else
		#define	RIO_059a_0		1
	#endif
#endif


#ifdef	PIN_PD0_IE
	#if(PIN_PD0_IE == ENABLE)
		#define	RIO_0599_0		1
	#else
		#define	RIO_0599_0		0
	#endif
#endif


#ifdef	PIN_PD0_DS
	#if(PIN_PD0_DS == ENABLE)
		#define	RIO_059d_0		1
	#else
		#define	RIO_059d_0		0
	#endif
#endif


#define	RIO_059b_0		PIN_PD0_DO


//-------- pin PD1 config ------//
#ifdef	PIN_PD1_FUNC
	#if(PIN_PD1_FUNC == PD1_AS_GPIO)
		#define	RIO_059e_1		1
	#endif
#endif


#ifdef	PIN_PD1_OE
	#if(PIN_PD1_OE == ENABLE)
		#define	RIO_059a_1		0
	#else
		#define	RIO_059a_1		1
	#endif
#endif


#ifdef	PIN_PD1_IE
	#if(PIN_PD1_IE == ENABLE)
		#define	RIO_0599_1		1
	#else
		#define	RIO_0599_1		0
	#endif
#endif


#ifdef	PIN_PD1_DS
	#if(PIN_PD1_DS == ENABLE)
		#define	RIO_059d_1		1
	#else
		#define	RIO_059d_1		0
	#endif
#endif


#define	RIO_059b_1		PIN_PD1_DO


//-------- pin PD2 config ------//
#ifdef	PIN_PD2_FUNC
	#if(PIN_PD2_FUNC == PD2_AS_GPIO)
		#define	RIO_059e_2		1
	#endif
#endif


#ifdef	PIN_PD2_OE
	#if(PIN_PD2_OE == ENABLE)
		#define	RIO_059a_2		0
	#else
		#define	RIO_059a_2		1
	#endif
#endif


#ifdef	PIN_PD2_IE
	#if(PIN_PD2_IE == ENABLE)
		#define	RIO_0599_2		1
	#else
		#define	RIO_0599_2		0
	#endif
#endif


#ifdef	PIN_PD2_DS
	#if(PIN_PD2_DS == ENABLE)
		#define	RIO_059d_2		1
	#else
		#define	RIO_059d_2		0
	#endif
#endif


#define	RIO_059b_2		PIN_PD2_DO


//-------- pin PD3 config ------//
#ifdef	PIN_PD3_FUNC
	#if(PIN_PD3_FUNC == PD3_AS_GPIO)
		#define	RIO_059e_3		1
	#endif
#endif


#ifdef	PIN_PD3_OE
	#if(PIN_PD3_OE == ENABLE)
		#define	RIO_059a_3		0
	#else
		#define	RIO_059a_3		1
	#endif
#endif


#ifdef	PIN_PD3_IE
	#if(PIN_PD3_IE == ENABLE)
		#define	RIO_0599_3		1
	#else
		#define	RIO_0599_3		0
	#endif
#endif


#ifdef	PIN_PD3_DS
	#if(PIN_PD3_DS == ENABLE)
		#define	RIO_059d_3		1
	#else
		#define	RIO_059d_3		0
	#endif
#endif


#define	RIO_059b_3		PIN_PD3_DO


//-------- pin PD4 config ------//
#ifdef	PIN_PD4_FUNC
	#if(PIN_PD4_FUNC == PD4_AS_GPIO)
		#define	RIO_059e_4		1
	#endif
#endif


#ifdef	PIN_PD4_OE
	#if(PIN_PD4_OE == ENABLE)
		#define	RIO_059a_4		0
	#else
		#define	RIO_059a_4		1
	#endif
#endif


#ifdef	PIN_PD4_IE
	#if(PIN_PD4_IE == ENABLE)
		#define	RIO_0599_4		1
	#else
		#define	RIO_0599_4		0
	#endif
#endif


#ifdef	PIN_PD4_DS
	#if(PIN_PD4_DS == ENABLE)
		#define	RIO_059d_4		1
	#else
		#define	RIO_059d_4		0
	#endif
#endif


#define	RIO_059b_4		PIN_PD4_DO


//-------- pin PD5 config ------//
#ifdef	PIN_PD5_FUNC
	#if(PIN_PD5_FUNC == PD5_AS_GPIO)
		#define	RIO_059e_5		1
	#endif
#endif


#ifdef	PIN_PD5_OE
	#if(PIN_PD5_OE == ENABLE)
		#define	RIO_059a_5		0
	#else
		#define	RIO_059a_5		1
	#endif
#endif


#ifdef	PIN_PD5_IE
	#if(PIN_PD5_IE == ENABLE)
		#define	RIO_0599_5		1
	#else
		#define	RIO_0599_5		0
	#endif
#endif


#ifdef	PIN_PD5_DS
	#if(PIN_PD5_DS == ENABLE)
		#define	RIO_059d_5		1
	#else
		#define	RIO_059d_5		0
	#endif
#endif


#define	RIO_059b_5		PIN_PD5_DO


//-------- pin PD6 config ------//
#ifdef	PIN_PD6_FUNC
	#if(PIN_PD6_FUNC == PD6_AS_GPIO)
		#define	RIO_059e_6		1
	#endif
#endif


#ifdef	PIN_PD6_OE
	#if(PIN_PD6_OE == ENABLE)
		#define	RIO_059a_6		0
	#else
		#define	RIO_059a_6		1
	#endif
#endif


#ifdef	PIN_PD6_IE
	#if(PIN_PD6_IE == ENABLE)
		#define	RIO_0599_6		1
	#else
		#define	RIO_0599_6		0
	#endif
#endif


#ifdef	PIN_PD6_DS
	#if(PIN_PD6_DS == ENABLE)
		#define	RIO_059d_6		1
	#else
		#define	RIO_059d_6		0
	#endif
#endif


#define	RIO_059b_6		PIN_PD6_DO


//-------- pin PD7 config ------//
#ifdef	PIN_PD7_FUNC
	#if(PIN_PD7_FUNC == PD7_AS_GPIO)
		#define	RIO_059e_7		1
	#endif
#endif


#ifdef	PIN_PD7_OE
	#if(PIN_PD7_OE == ENABLE)
		#define	RIO_059a_7		0
	#else
		#define	RIO_059a_7		1
	#endif
#endif


#ifdef	PIN_PD7_IE
	#if(PIN_PD7_IE == ENABLE)
		#define	RIO_0599_7		1
	#else
		#define	RIO_0599_7		0
	#endif
#endif


#ifdef	PIN_PD7_DS
	#if(PIN_PD7_DS == ENABLE)
		#define	RIO_059d_7		1
	#else
		#define	RIO_059d_7		0
	#endif
#endif


#define	RIO_059b_7		PIN_PD7_DO


//-------- pin PE0 config ------//
#ifdef	PIN_PE0_FUNC
	#if(PIN_PE0_FUNC == PE0_AS_GPIO)
		#define	RIO_05a6_0		1
	#endif
#endif


#ifdef	PIN_PE0_OE
	#if(PIN_PE0_OE == ENABLE)
		#define	RIO_05a2_0		0
	#else
		#define	RIO_05a2_0		1
	#endif
#endif


#ifdef	PIN_PE0_IE
	#if(PIN_PE0_IE == ENABLE)
		#define	RIO_05a1_0		1
	#else
		#define	RIO_05a1_0		0
	#endif
#endif


#ifdef	PIN_PE0_DS
	#if(PIN_PE0_DS == ENABLE)
		#define	RIO_05a5_0		1
	#else
		#define	RIO_05a5_0		0
	#endif
#endif


#define	RIO_05a3_0		PIN_PE0_DO


//-------- pin PE1 config ------//
#ifdef	PIN_PE1_FUNC
	#if(PIN_PE1_FUNC == PE1_AS_GPIO)
		#define	RIO_05a6_1		1
	#endif
#endif


#ifdef	PIN_PE1_OE
	#if(PIN_PE1_OE == ENABLE)
		#define	RIO_05a2_1		0
	#else
		#define	RIO_05a2_1		1
	#endif
#endif


#ifdef	PIN_PE1_IE
	#if(PIN_PE1_IE == ENABLE)
		#define	RIO_05a1_1		1
	#else
		#define	RIO_05a1_1		0
	#endif
#endif


#ifdef	PIN_PE1_DS
	#if(PIN_PE1_DS == ENABLE)
		#define	RIO_05a5_1		1
	#else
		#define	RIO_05a5_1		0
	#endif
#endif


#define	RIO_05a3_1		PIN_PE1_DO


//-------- pin PE2 config ------//
#ifdef	PIN_PE2_FUNC
	#if(PIN_PE2_FUNC == PE2_AS_GPIO)
		#define	RIO_05a6_2		1
	#endif
#endif


#ifdef	PIN_PE2_OE
	#if(PIN_PE2_OE == ENABLE)
		#define	RIO_05a2_2		0
	#else
		#define	RIO_05a2_2		1
	#endif
#endif


#ifdef	PIN_PE2_IE
	#if(PIN_PE2_IE == ENABLE)
		#define	RIO_05a1_2		1
	#else
		#define	RIO_05a1_2		0
	#endif
#endif


#ifdef	PIN_PE2_DS
	#if(PIN_PE2_DS == ENABLE)
		#define	RIO_05a5_2		1
	#else
		#define	RIO_05a5_2		0
	#endif
#endif


#define	RIO_05a3_2		PIN_PE2_DO


//-------- pin PE3 config ------//
#ifdef	PIN_PE3_FUNC
	#if(PIN_PE3_FUNC == PE3_AS_GPIO)
		#define	RIO_05a6_3		1
	#endif
#endif


#ifdef	PIN_PE3_OE
	#if(PIN_PE3_OE == ENABLE)
		#define	RIO_05a2_3		0
	#else
		#define	RIO_05a2_3		1
	#endif
#endif


#ifdef	PIN_PE3_IE
	#if(PIN_PE3_IE == ENABLE)
		#define	RIO_05a1_3		1
	#else
		#define	RIO_05a1_3		0
	#endif
#endif


#ifdef	PIN_PE3_DS
	#if(PIN_PE3_DS == ENABLE)
		#define	RIO_05a5_3		1
	#else
		#define	RIO_05a5_3		0
	#endif
#endif


#define	RIO_05a3_3		PIN_PE3_DO


//-------- pin PE4 config ------//
#ifdef	PIN_PE4_FUNC
	#if(PIN_PE4_FUNC == PE4_AS_GPIO)
		#define	RIO_05a6_4		1
	#endif
#endif


#ifdef	PIN_PE4_OE
	#if(PIN_PE4_OE == ENABLE)
		#define	RIO_05a2_4		0
	#else
		#define	RIO_05a2_4		1
	#endif
#endif


#ifdef	PIN_PE4_IE
	#if(PIN_PE4_IE == ENABLE)
		#define	RIO_05a1_4		1
	#else
		#define	RIO_05a1_4		0
	#endif
#endif


#ifdef	PIN_PE4_DS
	#if(PIN_PE4_DS == ENABLE)
		#define	RIO_05a5_4		1
	#else
		#define	RIO_05a5_4		0
	#endif
#endif


#define	RIO_05a3_4		PIN_PE4_DO


//-------- pin PE5 config ------//
#ifdef	PIN_PE5_FUNC
	#if(PIN_PE5_FUNC == PE5_AS_GPIO)
		#define	RIO_05a6_5		1
	#endif
#endif


#ifdef	PIN_PE5_OE
	#if(PIN_PE5_OE == ENABLE)
		#define	RIO_05a2_5		0
	#else
		#define	RIO_05a2_5		1
	#endif
#endif


#ifdef	PIN_PE5_IE
	#if(PIN_PE5_IE == ENABLE)
		#define	RIO_05a1_5		1
	#else
		#define	RIO_05a1_5		0
	#endif
#endif


#ifdef	PIN_PE5_DS
	#if(PIN_PE5_DS == ENABLE)
		#define	RIO_05a5_5		1
	#else
		#define	RIO_05a5_5		0
	#endif
#endif


#define	RIO_05a3_5		PIN_PE5_DO


//-------- pin PE6 config ------//
#ifdef	PIN_PE6_FUNC
	#if(PIN_PE6_FUNC == PE6_AS_GPIO)
		#define	RIO_05a6_6		1
	#else
		#define	RIO_05a6_6		0
		#define	RIO_05b4_6		0
		#define	RIO_05b6_5		0
	#endif
#endif


#ifdef	PIN_PE6_OE
	#if(PIN_PE6_OE == ENABLE)
		#define	RIO_05a2_6		0
	#else
		#define	RIO_05a2_6		1
	#endif
#endif


#ifdef	PIN_PE6_IE
	#if(PIN_PE6_IE == ENABLE)
		#define	RIO_05a1_6		1
	#else
		#define	RIO_05a1_6		0
	#endif
#endif


#ifdef	PIN_PE6_DS
	#if(PIN_PE6_DS == ENABLE)
		#define	RIO_05a5_6		1
	#else
		#define	RIO_05a5_6		0
	#endif
#endif


#define	RIO_05a3_6		PIN_PE6_DO


//-------- pin PE7 config ------//
#ifdef	PIN_PE7_FUNC
	#if(PIN_PE7_FUNC == PE7_AS_GPIO)
		#define	RIO_05a6_7		1
	#endif
#endif


#ifdef	PIN_PE7_OE
	#if(PIN_PE7_OE == ENABLE)
		#define	RIO_05a2_7		0
	#else
		#define	RIO_05a2_7		1
	#endif
#endif


#ifdef	PIN_PE7_IE
	#if(PIN_PE7_IE == ENABLE)
		#define	RIO_05a1_7		1
	#else
		#define	RIO_05a1_7		0
	#endif
#endif


#ifdef	PIN_PE7_DS
	#if(PIN_PE7_DS == ENABLE)
		#define	RIO_05a5_7		1
	#else
		#define	RIO_05a5_7		0
	#endif
#endif


#define	RIO_05a3_7		PIN_PE7_DO


//-------- pin PF0 config ------//
#ifdef	PIN_PF0_FUNC
	#if(PIN_PF0_FUNC == PF0_AS_GPIO)
		#define	RIO_05ae_0		1
	#else
		#define	RIO_05ae_0		0
		#define	RIO_05b6_5		0
	#endif
#endif


#ifdef	PIN_PF0_OE
	#if(PIN_PF0_OE == ENABLE)
		#define	RIO_05aa_0		0
	#else
		#define	RIO_05aa_0		1
	#endif
#endif


#ifdef	PIN_PF0_IE
	#if(PIN_PF0_IE == ENABLE)
		#define	RIO_05a9_0		1
	#else
		#define	RIO_05a9_0		0
	#endif
#endif


#ifdef	PIN_PF0_DS
	#if(PIN_PF0_DS == ENABLE)
		#define	RIO_05ad_0		1
	#else
		#define	RIO_05ad_0		0
	#endif
#endif


#define	RIO_05ab_0		PIN_PF0_DO


//-------- pin PF1 config ------//
#ifdef	PIN_PF1_FUNC
	#if(PIN_PF1_FUNC == PF1_AS_GPIO)
		#define	RIO_05ae_1		1
	#else
		#define	RIO_05ae_1		0
	#endif
#endif


#ifdef	PIN_PF1_OE
	#if(PIN_PF1_OE == ENABLE)
		#define	RIO_05aa_1		0
	#else
		#define	RIO_05aa_1		1
	#endif
#endif


#ifdef	PIN_PF1_IE
	#if(PIN_PF1_IE == ENABLE)
		#define	RIO_05a9_1		1
	#else
		#define	RIO_05a9_1		0
	#endif
#endif


#ifdef	PIN_PF1_DS
	#if(PIN_PF1_DS == ENABLE)
		#define	RIO_05ad_1		1
	#else
		#define	RIO_05ad_1		0
	#endif
#endif


#define	RIO_05ab_1		PIN_PF1_DO


/************************
for debug: print the adr and bits of the gpio:
		adress		bits mask
		0581		ff
		0582		ff
		0583		ff
		0585		ff
		0586		ff
		0589		ff
		058a		ff
		058b		ff
		058d		ff
		058e		ff
		0591		ff
		0592		ff
		0593		ff
		0595		ff
		0596		ff
		0599		ff
		059a		ff
		059b		ff
		059d		ff
		059e		ff
		05a1		ff
		05a2		ff
		05a3		ff
		05a5		ff
		05a6		ff
		05a9		03
		05aa		03
		05ab		03
		05ad		03
		05ae		03
		05b4		40
		05b6		20
************************/
#ifndef	RIO_0581_0
	#define	RIO_0581_0		0
#endif
#ifndef	RIO_0581_1
	#define	RIO_0581_1		0
#endif
#ifndef	RIO_0581_2
	#define	RIO_0581_2		0
#endif
#ifndef	RIO_0581_3
	#define	RIO_0581_3		0
#endif
#ifndef	RIO_0581_4
	#define	RIO_0581_4		0
#endif
#ifndef	RIO_0581_5
	#define	RIO_0581_5		0
#endif
#ifndef	RIO_0581_6
	#define	RIO_0581_6		0
#endif
#ifndef	RIO_0581_7
	#define	RIO_0581_7		0
#endif
#ifndef	RIO_0582_0
	#define	RIO_0582_0		0
#endif
#ifndef	RIO_0582_1
	#define	RIO_0582_1		0
#endif
#ifndef	RIO_0582_2
	#define	RIO_0582_2		0
#endif
#ifndef	RIO_0582_3
	#define	RIO_0582_3		0
#endif
#ifndef	RIO_0582_4
	#define	RIO_0582_4		0
#endif
#ifndef	RIO_0582_5
	#define	RIO_0582_5		0
#endif
#ifndef	RIO_0582_6
	#define	RIO_0582_6		0
#endif
#ifndef	RIO_0582_7
	#define	RIO_0582_7		0
#endif
#ifndef	RIO_0583_0
	#define	RIO_0583_0		0
#endif
#ifndef	RIO_0583_1
	#define	RIO_0583_1		0
#endif
#ifndef	RIO_0583_2
	#define	RIO_0583_2		0
#endif
#ifndef	RIO_0583_3
	#define	RIO_0583_3		0
#endif
#ifndef	RIO_0583_4
	#define	RIO_0583_4		0
#endif
#ifndef	RIO_0583_5
	#define	RIO_0583_5		0
#endif
#ifndef	RIO_0583_6
	#define	RIO_0583_6		0
#endif
#ifndef	RIO_0583_7
	#define	RIO_0583_7		0
#endif
#ifndef	RIO_0585_0
	#define	RIO_0585_0		0
#endif
#ifndef	RIO_0585_1
	#define	RIO_0585_1		0
#endif
#ifndef	RIO_0585_2
	#define	RIO_0585_2		0
#endif
#ifndef	RIO_0585_3
	#define	RIO_0585_3		0
#endif
#ifndef	RIO_0585_4
	#define	RIO_0585_4		0
#endif
#ifndef	RIO_0585_5
	#define	RIO_0585_5		0
#endif
#ifndef	RIO_0585_6
	#define	RIO_0585_6		0
#endif
#ifndef	RIO_0585_7
	#define	RIO_0585_7		0
#endif
#ifndef	RIO_0586_0
	#define	RIO_0586_0		0
#endif
#ifndef	RIO_0586_1
	#define	RIO_0586_1		0
#endif
#ifndef	RIO_0586_2
	#define	RIO_0586_2		0
#endif
#ifndef	RIO_0586_3
	#define	RIO_0586_3		0
#endif
#ifndef	RIO_0586_4
	#define	RIO_0586_4		0
#endif
#ifndef	RIO_0586_5
	#define	RIO_0586_5		0
#endif
#ifndef	RIO_0586_6
	#define	RIO_0586_6		0
#endif
#ifndef	RIO_0586_7
	#define	RIO_0586_7		0
#endif
#ifndef	RIO_0589_0
	#define	RIO_0589_0		0
#endif
#ifndef	RIO_0589_1
	#define	RIO_0589_1		0
#endif
#ifndef	RIO_0589_2
	#define	RIO_0589_2		0
#endif
#ifndef	RIO_0589_3
	#define	RIO_0589_3		0
#endif
#ifndef	RIO_0589_4
	#define	RIO_0589_4		0
#endif
#ifndef	RIO_0589_5
	#define	RIO_0589_5		0
#endif
#ifndef	RIO_0589_6
	#define	RIO_0589_6		0
#endif
#ifndef	RIO_0589_7
	#define	RIO_0589_7		0
#endif
#ifndef	RIO_058a_0
	#define	RIO_058a_0		0
#endif
#ifndef	RIO_058a_1
	#define	RIO_058a_1		0
#endif
#ifndef	RIO_058a_2
	#define	RIO_058a_2		0
#endif
#ifndef	RIO_058a_3
	#define	RIO_058a_3		0
#endif
#ifndef	RIO_058a_4
	#define	RIO_058a_4		0
#endif
#ifndef	RIO_058a_5
	#define	RIO_058a_5		0
#endif
#ifndef	RIO_058a_6
	#define	RIO_058a_6		0
#endif
#ifndef	RIO_058a_7
	#define	RIO_058a_7		0
#endif
#ifndef	RIO_058b_0
	#define	RIO_058b_0		0
#endif
#ifndef	RIO_058b_1
	#define	RIO_058b_1		0
#endif
#ifndef	RIO_058b_2
	#define	RIO_058b_2		0
#endif
#ifndef	RIO_058b_3
	#define	RIO_058b_3		0
#endif
#ifndef	RIO_058b_4
	#define	RIO_058b_4		0
#endif
#ifndef	RIO_058b_5
	#define	RIO_058b_5		0
#endif
#ifndef	RIO_058b_6
	#define	RIO_058b_6		0
#endif
#ifndef	RIO_058b_7
	#define	RIO_058b_7		0
#endif
#ifndef	RIO_058d_0
	#define	RIO_058d_0		0
#endif
#ifndef	RIO_058d_1
	#define	RIO_058d_1		0
#endif
#ifndef	RIO_058d_2
	#define	RIO_058d_2		0
#endif
#ifndef	RIO_058d_3
	#define	RIO_058d_3		0
#endif
#ifndef	RIO_058d_4
	#define	RIO_058d_4		0
#endif
#ifndef	RIO_058d_5
	#define	RIO_058d_5		0
#endif
#ifndef	RIO_058d_6
	#define	RIO_058d_6		0
#endif
#ifndef	RIO_058d_7
	#define	RIO_058d_7		0
#endif
#ifndef	RIO_058e_0
	#define	RIO_058e_0		0
#endif
#ifndef	RIO_058e_1
	#define	RIO_058e_1		0
#endif
#ifndef	RIO_058e_2
	#define	RIO_058e_2		0
#endif
#ifndef	RIO_058e_3
	#define	RIO_058e_3		0
#endif
#ifndef	RIO_058e_4
	#define	RIO_058e_4		0
#endif
#ifndef	RIO_058e_5
	#define	RIO_058e_5		0
#endif
#ifndef	RIO_058e_6
	#define	RIO_058e_6		0
#endif
#ifndef	RIO_058e_7
	#define	RIO_058e_7		0
#endif
#ifndef	RIO_0591_0
	#define	RIO_0591_0		0
#endif
#ifndef	RIO_0591_1
	#define	RIO_0591_1		0
#endif
#ifndef	RIO_0591_2
	#define	RIO_0591_2		0
#endif
#ifndef	RIO_0591_3
	#define	RIO_0591_3		0
#endif
#ifndef	RIO_0591_4
	#define	RIO_0591_4		0
#endif
#ifndef	RIO_0591_5
	#define	RIO_0591_5		0
#endif
#ifndef	RIO_0591_6
	#define	RIO_0591_6		0
#endif
#ifndef	RIO_0591_7
	#define	RIO_0591_7		0
#endif
#ifndef	RIO_0592_0
	#define	RIO_0592_0		0
#endif
#ifndef	RIO_0592_1
	#define	RIO_0592_1		0
#endif
#ifndef	RIO_0592_2
	#define	RIO_0592_2		0
#endif
#ifndef	RIO_0592_3
	#define	RIO_0592_3		0
#endif
#ifndef	RIO_0592_4
	#define	RIO_0592_4		0
#endif
#ifndef	RIO_0592_5
	#define	RIO_0592_5		0
#endif
#ifndef	RIO_0592_6
	#define	RIO_0592_6		0
#endif
#ifndef	RIO_0592_7
	#define	RIO_0592_7		0
#endif
#ifndef	RIO_0593_0
	#define	RIO_0593_0		0
#endif
#ifndef	RIO_0593_1
	#define	RIO_0593_1		0
#endif
#ifndef	RIO_0593_2
	#define	RIO_0593_2		0
#endif
#ifndef	RIO_0593_3
	#define	RIO_0593_3		0
#endif
#ifndef	RIO_0593_4
	#define	RIO_0593_4		0
#endif
#ifndef	RIO_0593_5
	#define	RIO_0593_5		0
#endif
#ifndef	RIO_0593_6
	#define	RIO_0593_6		0
#endif
#ifndef	RIO_0593_7
	#define	RIO_0593_7		0
#endif
#ifndef	RIO_0595_0
	#define	RIO_0595_0		0
#endif
#ifndef	RIO_0595_1
	#define	RIO_0595_1		0
#endif
#ifndef	RIO_0595_2
	#define	RIO_0595_2		0
#endif
#ifndef	RIO_0595_3
	#define	RIO_0595_3		0
#endif
#ifndef	RIO_0595_4
	#define	RIO_0595_4		0
#endif
#ifndef	RIO_0595_5
	#define	RIO_0595_5		0
#endif
#ifndef	RIO_0595_6
	#define	RIO_0595_6		0
#endif
#ifndef	RIO_0595_7
	#define	RIO_0595_7		0
#endif
#ifndef	RIO_0596_0
	#define	RIO_0596_0		0
#endif
#ifndef	RIO_0596_1
	#define	RIO_0596_1		0
#endif
#ifndef	RIO_0596_2
	#define	RIO_0596_2		0
#endif
#ifndef	RIO_0596_3
	#define	RIO_0596_3		0
#endif
#ifndef	RIO_0596_4
	#define	RIO_0596_4		0
#endif
#ifndef	RIO_0596_5
	#define	RIO_0596_5		0
#endif
#ifndef	RIO_0596_6
	#define	RIO_0596_6		0
#endif
#ifndef	RIO_0596_7
	#define	RIO_0596_7		0
#endif
#ifndef	RIO_0599_0
	#define	RIO_0599_0		0
#endif
#ifndef	RIO_0599_1
	#define	RIO_0599_1		0
#endif
#ifndef	RIO_0599_2
	#define	RIO_0599_2		0
#endif
#ifndef	RIO_0599_3
	#define	RIO_0599_3		0
#endif
#ifndef	RIO_0599_4
	#define	RIO_0599_4		0
#endif
#ifndef	RIO_0599_5
	#define	RIO_0599_5		0
#endif
#ifndef	RIO_0599_6
	#define	RIO_0599_6		0
#endif
#ifndef	RIO_0599_7
	#define	RIO_0599_7		0
#endif
#ifndef	RIO_059a_0
	#define	RIO_059a_0		0
#endif
#ifndef	RIO_059a_1
	#define	RIO_059a_1		0
#endif
#ifndef	RIO_059a_2
	#define	RIO_059a_2		0
#endif
#ifndef	RIO_059a_3
	#define	RIO_059a_3		0
#endif
#ifndef	RIO_059a_4
	#define	RIO_059a_4		0
#endif
#ifndef	RIO_059a_5
	#define	RIO_059a_5		0
#endif
#ifndef	RIO_059a_6
	#define	RIO_059a_6		0
#endif
#ifndef	RIO_059a_7
	#define	RIO_059a_7		0
#endif
#ifndef	RIO_059b_0
	#define	RIO_059b_0		0
#endif
#ifndef	RIO_059b_1
	#define	RIO_059b_1		0
#endif
#ifndef	RIO_059b_2
	#define	RIO_059b_2		0
#endif
#ifndef	RIO_059b_3
	#define	RIO_059b_3		0
#endif
#ifndef	RIO_059b_4
	#define	RIO_059b_4		0
#endif
#ifndef	RIO_059b_5
	#define	RIO_059b_5		0
#endif
#ifndef	RIO_059b_6
	#define	RIO_059b_6		0
#endif
#ifndef	RIO_059b_7
	#define	RIO_059b_7		0
#endif
#ifndef	RIO_059d_0
	#define	RIO_059d_0		0
#endif
#ifndef	RIO_059d_1
	#define	RIO_059d_1		0
#endif
#ifndef	RIO_059d_2
	#define	RIO_059d_2		0
#endif
#ifndef	RIO_059d_3
	#define	RIO_059d_3		0
#endif
#ifndef	RIO_059d_4
	#define	RIO_059d_4		0
#endif
#ifndef	RIO_059d_5
	#define	RIO_059d_5		0
#endif
#ifndef	RIO_059d_6
	#define	RIO_059d_6		0
#endif
#ifndef	RIO_059d_7
	#define	RIO_059d_7		0
#endif
#ifndef	RIO_059e_0
	#define	RIO_059e_0		0
#endif
#ifndef	RIO_059e_1
	#define	RIO_059e_1		0
#endif
#ifndef	RIO_059e_2
	#define	RIO_059e_2		0
#endif
#ifndef	RIO_059e_3
	#define	RIO_059e_3		0
#endif
#ifndef	RIO_059e_4
	#define	RIO_059e_4		0
#endif
#ifndef	RIO_059e_5
	#define	RIO_059e_5		0
#endif
#ifndef	RIO_059e_6
	#define	RIO_059e_6		0
#endif
#ifndef	RIO_059e_7
	#define	RIO_059e_7		0
#endif
#ifndef	RIO_05a1_0
	#define	RIO_05a1_0		0
#endif
#ifndef	RIO_05a1_1
	#define	RIO_05a1_1		0
#endif
#ifndef	RIO_05a1_2
	#define	RIO_05a1_2		0
#endif
#ifndef	RIO_05a1_3
	#define	RIO_05a1_3		0
#endif
#ifndef	RIO_05a1_4
	#define	RIO_05a1_4		0
#endif
#ifndef	RIO_05a1_5
	#define	RIO_05a1_5		0
#endif
#ifndef	RIO_05a1_6
	#define	RIO_05a1_6		0
#endif
#ifndef	RIO_05a1_7
	#define	RIO_05a1_7		0
#endif
#ifndef	RIO_05a2_0
	#define	RIO_05a2_0		0
#endif
#ifndef	RIO_05a2_1
	#define	RIO_05a2_1		0
#endif
#ifndef	RIO_05a2_2
	#define	RIO_05a2_2		0
#endif
#ifndef	RIO_05a2_3
	#define	RIO_05a2_3		0
#endif
#ifndef	RIO_05a2_4
	#define	RIO_05a2_4		0
#endif
#ifndef	RIO_05a2_5
	#define	RIO_05a2_5		0
#endif
#ifndef	RIO_05a2_6
	#define	RIO_05a2_6		0
#endif
#ifndef	RIO_05a2_7
	#define	RIO_05a2_7		0
#endif
#ifndef	RIO_05a3_0
	#define	RIO_05a3_0		0
#endif
#ifndef	RIO_05a3_1
	#define	RIO_05a3_1		0
#endif
#ifndef	RIO_05a3_2
	#define	RIO_05a3_2		0
#endif
#ifndef	RIO_05a3_3
	#define	RIO_05a3_3		0
#endif
#ifndef	RIO_05a3_4
	#define	RIO_05a3_4		0
#endif
#ifndef	RIO_05a3_5
	#define	RIO_05a3_5		0
#endif
#ifndef	RIO_05a3_6
	#define	RIO_05a3_6		0
#endif
#ifndef	RIO_05a3_7
	#define	RIO_05a3_7		0
#endif
#ifndef	RIO_05a5_0
	#define	RIO_05a5_0		0
#endif
#ifndef	RIO_05a5_1
	#define	RIO_05a5_1		0
#endif
#ifndef	RIO_05a5_2
	#define	RIO_05a5_2		0
#endif
#ifndef	RIO_05a5_3
	#define	RIO_05a5_3		0
#endif
#ifndef	RIO_05a5_4
	#define	RIO_05a5_4		0
#endif
#ifndef	RIO_05a5_5
	#define	RIO_05a5_5		0
#endif
#ifndef	RIO_05a5_6
	#define	RIO_05a5_6		0
#endif
#ifndef	RIO_05a5_7
	#define	RIO_05a5_7		0
#endif
#ifndef	RIO_05a6_0
	#define	RIO_05a6_0		0
#endif
#ifndef	RIO_05a6_1
	#define	RIO_05a6_1		0
#endif
#ifndef	RIO_05a6_2
	#define	RIO_05a6_2		0
#endif
#ifndef	RIO_05a6_3
	#define	RIO_05a6_3		0
#endif
#ifndef	RIO_05a6_4
	#define	RIO_05a6_4		0
#endif
#ifndef	RIO_05a6_5
	#define	RIO_05a6_5		0
#endif
#ifndef	RIO_05a6_6
	#define	RIO_05a6_6		0
#endif
#ifndef	RIO_05a6_7
	#define	RIO_05a6_7		0
#endif
#ifndef	RIO_05a9_0
	#define	RIO_05a9_0		0
#endif
#ifndef	RIO_05a9_1
	#define	RIO_05a9_1		0
#endif
#ifndef	RIO_05aa_0
	#define	RIO_05aa_0		0
#endif
#ifndef	RIO_05aa_1
	#define	RIO_05aa_1		0
#endif
#ifndef	RIO_05ab_0
	#define	RIO_05ab_0		0
#endif
#ifndef	RIO_05ab_1
	#define	RIO_05ab_1		0
#endif
#ifndef	RIO_05ad_0
	#define	RIO_05ad_0		0
#endif
#ifndef	RIO_05ad_1
	#define	RIO_05ad_1		0
#endif
#ifndef	RIO_05ae_0
	#define	RIO_05ae_0		0
#endif
#ifndef	RIO_05ae_1
	#define	RIO_05ae_1		0
#endif
#ifndef	RIO_05b4_6
	#define	RIO_05b4_6		0
#endif
#ifndef	RIO_05b6_5
	#define	RIO_05b6_5		0
#endif
//some macro for bits->byte, byte->long


#define	BITS2BYTE(name)	((name##_7)<<7)|((name##_6)<<6)|((name##_5)<<5)|((name##_4)<<4)|\
								((name##_3)<<3)|((name##_2)<<2)|((name##_1)<<1)|(name##_0)

#define		BYTE2LONG(byte3,byte2,byte1,byte0)		(((byte3)<<24)|((byte2)<<16)|((byte1)<<8)|byte0)

#define		BYTE_EMPTY		0
//bitmask of 0581 is ff
#define		RIO_0581_BYTE		BITS2BYTE(RIO_0581)
//bitmask of 0582 is ff
#define		RIO_0582_BYTE		BITS2BYTE(RIO_0582)
//bitmask of 0583 is ff
#define		RIO_0583_BYTE		BITS2BYTE(RIO_0583)
//bitmask of 0585 is ff
#define		RIO_0585_BYTE		BITS2BYTE(RIO_0585)
//bitmask of 0586 is ff
#define		RIO_0586_BYTE		BITS2BYTE(RIO_0586)
//bitmask of 0589 is ff
#define		RIO_0589_BYTE		BITS2BYTE(RIO_0589)
//bitmask of 058a is ff
#define		RIO_058a_BYTE		BITS2BYTE(RIO_058a)
//bitmask of 058b is ff
#define		RIO_058b_BYTE		BITS2BYTE(RIO_058b)
//bitmask of 058d is ff
#define		RIO_058d_BYTE		BITS2BYTE(RIO_058d)
//bitmask of 058e is ff
#define		RIO_058e_BYTE		BITS2BYTE(RIO_058e)
//bitmask of 0591 is ff
#define		RIO_0591_BYTE		BITS2BYTE(RIO_0591)
//bitmask of 0592 is ff
#define		RIO_0592_BYTE		BITS2BYTE(RIO_0592)
//bitmask of 0593 is ff
#define		RIO_0593_BYTE		BITS2BYTE(RIO_0593)
//bitmask of 0595 is ff
#define		RIO_0595_BYTE		BITS2BYTE(RIO_0595)
//bitmask of 0596 is ff
#define		RIO_0596_BYTE		BITS2BYTE(RIO_0596)
//bitmask of 0599 is ff
#define		RIO_0599_BYTE		BITS2BYTE(RIO_0599)
//bitmask of 059a is ff
#define		RIO_059a_BYTE		BITS2BYTE(RIO_059a)
//bitmask of 059b is ff
#define		RIO_059b_BYTE		BITS2BYTE(RIO_059b)
//bitmask of 059d is ff
#define		RIO_059d_BYTE		BITS2BYTE(RIO_059d)
//bitmask of 059e is ff
#define		RIO_059e_BYTE		BITS2BYTE(RIO_059e)
//bitmask of 05a1 is ff
#define		RIO_05a1_BYTE		BITS2BYTE(RIO_05a1)
//bitmask of 05a2 is ff
#define		RIO_05a2_BYTE		BITS2BYTE(RIO_05a2)
//bitmask of 05a3 is ff
#define		RIO_05a3_BYTE		BITS2BYTE(RIO_05a3)
//bitmask of 05a5 is ff
#define		RIO_05a5_BYTE		BITS2BYTE(RIO_05a5)
//bitmask of 05a6 is ff
#define		RIO_05a6_BYTE		BITS2BYTE(RIO_05a6)
//bitmask of 05a9 is 03
#define		RIO_05a9_BYTE		BITS2BYTE(RIO_05a9)
//bitmask of 05aa is 03
#define		RIO_05aa_BYTE		BITS2BYTE(RIO_05aa)
//bitmask of 05ab is 03
#define		RIO_05ab_BYTE		BITS2BYTE(RIO_05ab)
//bitmask of 05ad is 03
#define		RIO_05ad_BYTE		BITS2BYTE(RIO_05ad)
//bitmask of 05ae is 03
#define		RIO_05ae_BYTE		BITS2BYTE(RIO_05ae)
//bitmask of 05b4 is 40
//bitmask of 05b6 is 20


#define	RIO_05b4_LONG		BYTE2LONG(BYTE_EMPTY,BYTE_EMPTY,RIO_05b6_BYTE,RIO_05b4_BYTE)





/********************************************************************
* // next is for the config of individual pins.
********************************************************************/
/n#ifndef	write_reg32
#define	write_reg16(addr,data)		(*(volatile unsigned short *)(addr)=data)
#endif

/n#ifndef	write_reg16
#define	write_reg16(addr,data)		(*(volatile unsigned short *)(addr)=data)
#endif

/n#ifndef	write_reg8
#define	write_reg8(addr,data)		(*(volatile unsigned char  *)(addr)=data)
#endif

/n#ifndef	read_reg32
#define	read_reg32(addr)		(*(volatile unsigned long  *)(addr))
#endif

/n#ifndef	read_reg16
#define	read_reg16(addr)		(*(volatile unsigned short  *)(addr))
#endif

/n#ifndef	read_reg8
#define	read_reg8(addr)		(*(volatile unsigned char  *)(addr))
#endif

#define 	IO_BIT_VALUE(reg, bit) 	(((read_reg8(reg) & (1 << bit)) >> bit) == 1)
#define 	IO_BIT_CLR(reg, bit)  	write_reg8(reg,(read_reg8(reg) & ~(1 << bit)))
#define 	IO_BIT_SET(reg, bit)  	write_reg8(reg,(read_reg8(reg) | (1 << bit)))



//-------------- pin PA0---------------------------//
#define		PIN_PA0_AS_GPIO		IO_BIT_SET(0x800586,0)
#define		PIN_PA0_AS_SWS		IO_BIT_CLR(0x800586,0)
#define		PIN_PA0_OE_SET		IO_BIT_CLR(0x800582,0)
#define		PIN_PA0_OE_CLR		IO_BIT_SET(0x800582,0)
#define		PIN_PA0_DS_SET		IO_BIT_SET(0x800581,0)
#define		PIN_PA0_DS_CLR		IO_BIT_CLR(0x800581,0)
#define		PIN_PA0_DS_SET		IO_BIT_SET(0x800585,0)
#define		PIN_PA0_DS_CLR		IO_BIT_CLR(0x800585,0)
#define		PIN_PA0_OUT_H		IO_BIT_SET(0x800583,0)
#define		PIN_PA0_OUT_L		IO_BIT_CLR(0x800583,0)
#define		PIN_PA0_INPUT		IO_BIT_VALUE(0x800580,0)


//-------------- pin PA1---------------------------//
#define		PIN_PA1_AS_GPIO		IO_BIT_SET(0x800586,1)
#define		PIN_PA1_OE_SET		IO_BIT_CLR(0x800582,1)
#define		PIN_PA1_OE_CLR		IO_BIT_SET(0x800582,1)
#define		PIN_PA1_DS_SET		IO_BIT_SET(0x800581,1)
#define		PIN_PA1_DS_CLR		IO_BIT_CLR(0x800581,1)
#define		PIN_PA1_DS_SET		IO_BIT_SET(0x800585,1)
#define		PIN_PA1_DS_CLR		IO_BIT_CLR(0x800585,1)
#define		PIN_PA1_OUT_H		IO_BIT_SET(0x800583,1)
#define		PIN_PA1_OUT_L		IO_BIT_CLR(0x800583,1)
#define		PIN_PA1_INPUT		IO_BIT_VALUE(0x800580,1)


//-------------- pin PA2---------------------------//
#define		PIN_PA2_AS_GPIO		IO_BIT_SET(0x800586,2)
#define		PIN_PA2_AS_MSDI		IO_BIT_CLR(0x800586,2)
#define		PIN_PA2_OE_SET		IO_BIT_CLR(0x800582,2)
#define		PIN_PA2_OE_CLR		IO_BIT_SET(0x800582,2)
#define		PIN_PA2_DS_SET		IO_BIT_SET(0x800581,2)
#define		PIN_PA2_DS_CLR		IO_BIT_CLR(0x800581,2)
#define		PIN_PA2_DS_SET		IO_BIT_SET(0x800585,2)
#define		PIN_PA2_DS_CLR		IO_BIT_CLR(0x800585,2)
#define		PIN_PA2_OUT_H		IO_BIT_SET(0x800583,2)
#define		PIN_PA2_OUT_L		IO_BIT_CLR(0x800583,2)
#define		PIN_PA2_INPUT		IO_BIT_VALUE(0x800580,2)


//-------------- pin PA3---------------------------//
#define		PIN_PA3_AS_GPIO		IO_BIT_SET(0x800586,3)
#define		PIN_PA3_AS_MCLK		IO_BIT_CLR(0x800586,3)
#define		PIN_PA3_OE_SET		IO_BIT_CLR(0x800582,3)
#define		PIN_PA3_OE_CLR		IO_BIT_SET(0x800582,3)
#define		PIN_PA3_DS_SET		IO_BIT_SET(0x800581,3)
#define		PIN_PA3_DS_CLR		IO_BIT_CLR(0x800581,3)
#define		PIN_PA3_DS_SET		IO_BIT_SET(0x800585,3)
#define		PIN_PA3_DS_CLR		IO_BIT_CLR(0x800585,3)
#define		PIN_PA3_OUT_H		IO_BIT_SET(0x800583,3)
#define		PIN_PA3_OUT_L		IO_BIT_CLR(0x800583,3)
#define		PIN_PA3_INPUT		IO_BIT_VALUE(0x800580,3)


//-------------- pin PA4---------------------------//
#define		PIN_PA4_AS_GPIO		IO_BIT_SET(0x800586,4)
#define		PIN_PA4_OE_SET		IO_BIT_CLR(0x800582,4)
#define		PIN_PA4_OE_CLR		IO_BIT_SET(0x800582,4)
#define		PIN_PA4_DS_SET		IO_BIT_SET(0x800581,4)
#define		PIN_PA4_DS_CLR		IO_BIT_CLR(0x800581,4)
#define		PIN_PA4_DS_SET		IO_BIT_SET(0x800585,4)
#define		PIN_PA4_DS_CLR		IO_BIT_CLR(0x800585,4)
#define		PIN_PA4_OUT_H		IO_BIT_SET(0x800583,4)
#define		PIN_PA4_OUT_L		IO_BIT_CLR(0x800583,4)
#define		PIN_PA4_INPUT		IO_BIT_VALUE(0x800580,4)


//-------------- pin PA5---------------------------//
#define		PIN_PA5_AS_GPIO		IO_BIT_SET(0x800586,5)
#define		PIN_PA5_OE_SET		IO_BIT_CLR(0x800582,5)
#define		PIN_PA5_OE_CLR		IO_BIT_SET(0x800582,5)
#define		PIN_PA5_DS_SET		IO_BIT_SET(0x800581,5)
#define		PIN_PA5_DS_CLR		IO_BIT_CLR(0x800581,5)
#define		PIN_PA5_DS_SET		IO_BIT_SET(0x800585,5)
#define		PIN_PA5_DS_CLR		IO_BIT_CLR(0x800585,5)
#define		PIN_PA5_OUT_H		IO_BIT_SET(0x800583,5)
#define		PIN_PA5_OUT_L		IO_BIT_CLR(0x800583,5)
#define		PIN_PA5_INPUT		IO_BIT_VALUE(0x800580,5)


//-------------- pin PA6---------------------------//
#define		PIN_PA6_AS_GPIO		IO_BIT_SET(0x800586,6)
#define		PIN_PA6_OE_SET		IO_BIT_CLR(0x800582,6)
#define		PIN_PA6_OE_CLR		IO_BIT_SET(0x800582,6)
#define		PIN_PA6_DS_SET		IO_BIT_SET(0x800581,6)
#define		PIN_PA6_DS_CLR		IO_BIT_CLR(0x800581,6)
#define		PIN_PA6_DS_SET		IO_BIT_SET(0x800585,6)
#define		PIN_PA6_DS_CLR		IO_BIT_CLR(0x800585,6)
#define		PIN_PA6_OUT_H		IO_BIT_SET(0x800583,6)
#define		PIN_PA6_OUT_L		IO_BIT_CLR(0x800583,6)
#define		PIN_PA6_INPUT		IO_BIT_VALUE(0x800580,6)


//-------------- pin PA7---------------------------//
#define		PIN_PA7_AS_GPIO		IO_BIT_SET(0x800586,7)
#define		PIN_PA7_OE_SET		IO_BIT_CLR(0x800582,7)
#define		PIN_PA7_OE_CLR		IO_BIT_SET(0x800582,7)
#define		PIN_PA7_DS_SET		IO_BIT_SET(0x800581,7)
#define		PIN_PA7_DS_CLR		IO_BIT_CLR(0x800581,7)
#define		PIN_PA7_DS_SET		IO_BIT_SET(0x800585,7)
#define		PIN_PA7_DS_CLR		IO_BIT_CLR(0x800585,7)
#define		PIN_PA7_OUT_H		IO_BIT_SET(0x800583,7)
#define		PIN_PA7_OUT_L		IO_BIT_CLR(0x800583,7)
#define		PIN_PA7_INPUT		IO_BIT_VALUE(0x800580,7)


//-------------- pin PB0---------------------------//
#define		PIN_PB0_AS_GPIO		IO_BIT_SET(0x80058e,0)
#define		PIN_PB0_OE_SET		IO_BIT_CLR(0x80058a,0)
#define		PIN_PB0_OE_CLR		IO_BIT_SET(0x80058a,0)
#define		PIN_PB0_DS_SET		IO_BIT_SET(0x800589,0)
#define		PIN_PB0_DS_CLR		IO_BIT_CLR(0x800589,0)
#define		PIN_PB0_DS_SET		IO_BIT_SET(0x80058d,0)
#define		PIN_PB0_DS_CLR		IO_BIT_CLR(0x80058d,0)
#define		PIN_PB0_OUT_H		IO_BIT_SET(0x80058b,0)
#define		PIN_PB0_OUT_L		IO_BIT_CLR(0x80058b,0)
#define		PIN_PB0_INPUT		IO_BIT_VALUE(0x800588,0)


//-------------- pin PB1---------------------------//
#define		PIN_PB1_AS_GPIO		IO_BIT_SET(0x80058e,1)
#define		PIN_PB1_OE_SET		IO_BIT_CLR(0x80058a,1)
#define		PIN_PB1_OE_CLR		IO_BIT_SET(0x80058a,1)
#define		PIN_PB1_DS_SET		IO_BIT_SET(0x800589,1)
#define		PIN_PB1_DS_CLR		IO_BIT_CLR(0x800589,1)
#define		PIN_PB1_DS_SET		IO_BIT_SET(0x80058d,1)
#define		PIN_PB1_DS_CLR		IO_BIT_CLR(0x80058d,1)
#define		PIN_PB1_OUT_H		IO_BIT_SET(0x80058b,1)
#define		PIN_PB1_OUT_L		IO_BIT_CLR(0x80058b,1)
#define		PIN_PB1_INPUT		IO_BIT_VALUE(0x800588,1)


//-------------- pin PB2---------------------------//
#define		PIN_PB2_AS_GPIO		IO_BIT_SET(0x80058e,2)
#define		PIN_PB2_AS_MSDO		IO_BIT_CLR(0x80058e,2)
#define		PIN_PB2_OE_SET		IO_BIT_CLR(0x80058a,2)
#define		PIN_PB2_OE_CLR		IO_BIT_SET(0x80058a,2)
#define		PIN_PB2_DS_SET		IO_BIT_SET(0x800589,2)
#define		PIN_PB2_DS_CLR		IO_BIT_CLR(0x800589,2)
#define		PIN_PB2_DS_SET		IO_BIT_SET(0x80058d,2)
#define		PIN_PB2_DS_CLR		IO_BIT_CLR(0x80058d,2)
#define		PIN_PB2_OUT_H		IO_BIT_SET(0x80058b,2)
#define		PIN_PB2_OUT_L		IO_BIT_CLR(0x80058b,2)
#define		PIN_PB2_INPUT		IO_BIT_VALUE(0x800588,2)


//-------------- pin PB3---------------------------//
#define		PIN_PB3_AS_GPIO		IO_BIT_SET(0x80058e,3)
#define		PIN_PB3_AS_MSCN		IO_BIT_CLR(0x80058e,3)
#define		PIN_PB3_OE_SET		IO_BIT_CLR(0x80058a,3)
#define		PIN_PB3_OE_CLR		IO_BIT_SET(0x80058a,3)
#define		PIN_PB3_DS_SET		IO_BIT_SET(0x800589,3)
#define		PIN_PB3_DS_CLR		IO_BIT_CLR(0x800589,3)
#define		PIN_PB3_DS_SET		IO_BIT_SET(0x80058d,3)
#define		PIN_PB3_DS_CLR		IO_BIT_CLR(0x80058d,3)
#define		PIN_PB3_OUT_H		IO_BIT_SET(0x80058b,3)
#define		PIN_PB3_OUT_L		IO_BIT_CLR(0x80058b,3)
#define		PIN_PB3_INPUT		IO_BIT_VALUE(0x800588,3)


//-------------- pin PB4---------------------------//
#define		PIN_PB4_AS_GPIO		IO_BIT_SET(0x80058e,4)
#define		PIN_PB4_OE_SET		IO_BIT_CLR(0x80058a,4)
#define		PIN_PB4_OE_CLR		IO_BIT_SET(0x80058a,4)
#define		PIN_PB4_DS_SET		IO_BIT_SET(0x800589,4)
#define		PIN_PB4_DS_CLR		IO_BIT_CLR(0x800589,4)
#define		PIN_PB4_DS_SET		IO_BIT_SET(0x80058d,4)
#define		PIN_PB4_DS_CLR		IO_BIT_CLR(0x80058d,4)
#define		PIN_PB4_OUT_H		IO_BIT_SET(0x80058b,4)
#define		PIN_PB4_OUT_L		IO_BIT_CLR(0x80058b,4)
#define		PIN_PB4_INPUT		IO_BIT_VALUE(0x800588,4)


//-------------- pin PB5---------------------------//
#define		PIN_PB5_AS_GPIO		IO_BIT_SET(0x80058e,5)
#define		PIN_PB5_AS_DM		IO_BIT_CLR(0x80058e,5)
#define		PIN_PB5_OE_SET		IO_BIT_CLR(0x80058a,5)
#define		PIN_PB5_OE_CLR		IO_BIT_SET(0x80058a,5)
#define		PIN_PB5_DS_SET		IO_BIT_SET(0x800589,5)
#define		PIN_PB5_DS_CLR		IO_BIT_CLR(0x800589,5)
#define		PIN_PB5_DS_SET		IO_BIT_SET(0x80058d,5)
#define		PIN_PB5_DS_CLR		IO_BIT_CLR(0x80058d,5)
#define		PIN_PB5_OUT_H		IO_BIT_SET(0x80058b,5)
#define		PIN_PB5_OUT_L		IO_BIT_CLR(0x80058b,5)
#define		PIN_PB5_INPUT		IO_BIT_VALUE(0x800588,5)


//-------------- pin PB6---------------------------//
#define		PIN_PB6_AS_GPIO		IO_BIT_SET(0x80058e,6)
#define		PIN_PB6_AS_DP		IO_BIT_CLR(0x80058e,6)
#define		PIN_PB6_OE_SET		IO_BIT_CLR(0x80058a,6)
#define		PIN_PB6_OE_CLR		IO_BIT_SET(0x80058a,6)
#define		PIN_PB6_DS_SET		IO_BIT_SET(0x800589,6)
#define		PIN_PB6_DS_CLR		IO_BIT_CLR(0x800589,6)
#define		PIN_PB6_DS_SET		IO_BIT_SET(0x80058d,6)
#define		PIN_PB6_DS_CLR		IO_BIT_CLR(0x80058d,6)
#define		PIN_PB6_OUT_H		IO_BIT_SET(0x80058b,6)
#define		PIN_PB6_OUT_L		IO_BIT_CLR(0x80058b,6)
#define		PIN_PB6_INPUT		IO_BIT_VALUE(0x800588,6)


//-------------- pin PB7---------------------------//
#define		PIN_PB7_AS_GPIO		IO_BIT_SET(0x80058e,7)
#define		PIN_PB7_OE_SET		IO_BIT_CLR(0x80058a,7)
#define		PIN_PB7_OE_CLR		IO_BIT_SET(0x80058a,7)
#define		PIN_PB7_DS_SET		IO_BIT_SET(0x800589,7)
#define		PIN_PB7_DS_CLR		IO_BIT_CLR(0x800589,7)
#define		PIN_PB7_DS_SET		IO_BIT_SET(0x80058d,7)
#define		PIN_PB7_DS_CLR		IO_BIT_CLR(0x80058d,7)
#define		PIN_PB7_OUT_H		IO_BIT_SET(0x80058b,7)
#define		PIN_PB7_OUT_L		IO_BIT_CLR(0x80058b,7)
#define		PIN_PB7_INPUT		IO_BIT_VALUE(0x800588,7)


//-------------- pin PC0---------------------------//
#define		PIN_PC0_AS_GPIO		IO_BIT_SET(0x800596,0)
#define		PIN_PC0_OE_SET		IO_BIT_CLR(0x800592,0)
#define		PIN_PC0_OE_CLR		IO_BIT_SET(0x800592,0)
#define		PIN_PC0_DS_SET		IO_BIT_SET(0x800591,0)
#define		PIN_PC0_DS_CLR		IO_BIT_CLR(0x800591,0)
#define		PIN_PC0_DS_SET		IO_BIT_SET(0x800595,0)
#define		PIN_PC0_DS_CLR		IO_BIT_CLR(0x800595,0)
#define		PIN_PC0_OUT_H		IO_BIT_SET(0x800593,0)
#define		PIN_PC0_OUT_L		IO_BIT_CLR(0x800593,0)
#define		PIN_PC0_INPUT		IO_BIT_VALUE(0x800590,0)


//-------------- pin PC1---------------------------//
#define		PIN_PC1_AS_GPIO		IO_BIT_SET(0x800596,1)
#define		PIN_PC1_OE_SET		IO_BIT_CLR(0x800592,1)
#define		PIN_PC1_OE_CLR		IO_BIT_SET(0x800592,1)
#define		PIN_PC1_DS_SET		IO_BIT_SET(0x800591,1)
#define		PIN_PC1_DS_CLR		IO_BIT_CLR(0x800591,1)
#define		PIN_PC1_DS_SET		IO_BIT_SET(0x800595,1)
#define		PIN_PC1_DS_CLR		IO_BIT_CLR(0x800595,1)
#define		PIN_PC1_OUT_H		IO_BIT_SET(0x800593,1)
#define		PIN_PC1_OUT_L		IO_BIT_CLR(0x800593,1)
#define		PIN_PC1_INPUT		IO_BIT_VALUE(0x800590,1)


//-------------- pin PC2---------------------------//
#define		PIN_PC2_AS_GPIO		IO_BIT_SET(0x800596,2)
#define		PIN_PC2_OE_SET		IO_BIT_CLR(0x800592,2)
#define		PIN_PC2_OE_CLR		IO_BIT_SET(0x800592,2)
#define		PIN_PC2_DS_SET		IO_BIT_SET(0x800591,2)
#define		PIN_PC2_DS_CLR		IO_BIT_CLR(0x800591,2)
#define		PIN_PC2_DS_SET		IO_BIT_SET(0x800595,2)
#define		PIN_PC2_DS_CLR		IO_BIT_CLR(0x800595,2)
#define		PIN_PC2_OUT_H		IO_BIT_SET(0x800593,2)
#define		PIN_PC2_OUT_L		IO_BIT_CLR(0x800593,2)
#define		PIN_PC2_INPUT		IO_BIT_VALUE(0x800590,2)


//-------------- pin PC3---------------------------//
#define		PIN_PC3_AS_GPIO		IO_BIT_SET(0x800596,3)
#define		PIN_PC3_OE_SET		IO_BIT_CLR(0x800592,3)
#define		PIN_PC3_OE_CLR		IO_BIT_SET(0x800592,3)
#define		PIN_PC3_DS_SET		IO_BIT_SET(0x800591,3)
#define		PIN_PC3_DS_CLR		IO_BIT_CLR(0x800591,3)
#define		PIN_PC3_DS_SET		IO_BIT_SET(0x800595,3)
#define		PIN_PC3_DS_CLR		IO_BIT_CLR(0x800595,3)
#define		PIN_PC3_OUT_H		IO_BIT_SET(0x800593,3)
#define		PIN_PC3_OUT_L		IO_BIT_CLR(0x800593,3)
#define		PIN_PC3_INPUT		IO_BIT_VALUE(0x800590,3)


//-------------- pin PC4---------------------------//
#define		PIN_PC4_AS_GPIO		IO_BIT_SET(0x800596,4)
#define		PIN_PC4_OE_SET		IO_BIT_CLR(0x800592,4)
#define		PIN_PC4_OE_CLR		IO_BIT_SET(0x800592,4)
#define		PIN_PC4_DS_SET		IO_BIT_SET(0x800591,4)
#define		PIN_PC4_DS_CLR		IO_BIT_CLR(0x800591,4)
#define		PIN_PC4_DS_SET		IO_BIT_SET(0x800595,4)
#define		PIN_PC4_DS_CLR		IO_BIT_CLR(0x800595,4)
#define		PIN_PC4_OUT_H		IO_BIT_SET(0x800593,4)
#define		PIN_PC4_OUT_L		IO_BIT_CLR(0x800593,4)
#define		PIN_PC4_INPUT		IO_BIT_VALUE(0x800590,4)


//-------------- pin PC5---------------------------//
#define		PIN_PC5_AS_GPIO		IO_BIT_SET(0x800596,5)
#define		PIN_PC5_OE_SET		IO_BIT_CLR(0x800592,5)
#define		PIN_PC5_OE_CLR		IO_BIT_SET(0x800592,5)
#define		PIN_PC5_DS_SET		IO_BIT_SET(0x800591,5)
#define		PIN_PC5_DS_CLR		IO_BIT_CLR(0x800591,5)
#define		PIN_PC5_DS_SET		IO_BIT_SET(0x800595,5)
#define		PIN_PC5_DS_CLR		IO_BIT_CLR(0x800595,5)
#define		PIN_PC5_OUT_H		IO_BIT_SET(0x800593,5)
#define		PIN_PC5_OUT_L		IO_BIT_CLR(0x800593,5)
#define		PIN_PC5_INPUT		IO_BIT_VALUE(0x800590,5)


//-------------- pin PC6---------------------------//
#define		PIN_PC6_AS_GPIO		IO_BIT_SET(0x800596,6)
#define		PIN_PC6_OE_SET		IO_BIT_CLR(0x800592,6)
#define		PIN_PC6_OE_CLR		IO_BIT_SET(0x800592,6)
#define		PIN_PC6_DS_SET		IO_BIT_SET(0x800591,6)
#define		PIN_PC6_DS_CLR		IO_BIT_CLR(0x800591,6)
#define		PIN_PC6_DS_SET		IO_BIT_SET(0x800595,6)
#define		PIN_PC6_DS_CLR		IO_BIT_CLR(0x800595,6)
#define		PIN_PC6_OUT_H		IO_BIT_SET(0x800593,6)
#define		PIN_PC6_OUT_L		IO_BIT_CLR(0x800593,6)
#define		PIN_PC6_INPUT		IO_BIT_VALUE(0x800590,6)


//-------------- pin PC7---------------------------//
#define		PIN_PC7_AS_GPIO		IO_BIT_SET(0x800596,7)
#define		PIN_PC7_OE_SET		IO_BIT_CLR(0x800592,7)
#define		PIN_PC7_OE_CLR		IO_BIT_SET(0x800592,7)
#define		PIN_PC7_DS_SET		IO_BIT_SET(0x800591,7)
#define		PIN_PC7_DS_CLR		IO_BIT_CLR(0x800591,7)
#define		PIN_PC7_DS_SET		IO_BIT_SET(0x800595,7)
#define		PIN_PC7_DS_CLR		IO_BIT_CLR(0x800595,7)
#define		PIN_PC7_OUT_H		IO_BIT_SET(0x800593,7)
#define		PIN_PC7_OUT_L		IO_BIT_CLR(0x800593,7)
#define		PIN_PC7_INPUT		IO_BIT_VALUE(0x800590,7)


//-------------- pin PD0---------------------------//
#define		PIN_PD0_AS_GPIO		IO_BIT_SET(0x80059e,0)
#define		PIN_PD0_OE_SET		IO_BIT_CLR(0x80059a,0)
#define		PIN_PD0_OE_CLR		IO_BIT_SET(0x80059a,0)
#define		PIN_PD0_DS_SET		IO_BIT_SET(0x800599,0)
#define		PIN_PD0_DS_CLR		IO_BIT_CLR(0x800599,0)
#define		PIN_PD0_DS_SET		IO_BIT_SET(0x80059d,0)
#define		PIN_PD0_DS_CLR		IO_BIT_CLR(0x80059d,0)
#define		PIN_PD0_OUT_H		IO_BIT_SET(0x80059b,0)
#define		PIN_PD0_OUT_L		IO_BIT_CLR(0x80059b,0)
#define		PIN_PD0_INPUT		IO_BIT_VALUE(0x800598,0)


//-------------- pin PD1---------------------------//
#define		PIN_PD1_AS_GPIO		IO_BIT_SET(0x80059e,1)
#define		PIN_PD1_OE_SET		IO_BIT_CLR(0x80059a,1)
#define		PIN_PD1_OE_CLR		IO_BIT_SET(0x80059a,1)
#define		PIN_PD1_DS_SET		IO_BIT_SET(0x800599,1)
#define		PIN_PD1_DS_CLR		IO_BIT_CLR(0x800599,1)
#define		PIN_PD1_DS_SET		IO_BIT_SET(0x80059d,1)
#define		PIN_PD1_DS_CLR		IO_BIT_CLR(0x80059d,1)
#define		PIN_PD1_OUT_H		IO_BIT_SET(0x80059b,1)
#define		PIN_PD1_OUT_L		IO_BIT_CLR(0x80059b,1)
#define		PIN_PD1_INPUT		IO_BIT_VALUE(0x800598,1)


//-------------- pin PD2---------------------------//
#define		PIN_PD2_AS_GPIO		IO_BIT_SET(0x80059e,2)
#define		PIN_PD2_OE_SET		IO_BIT_CLR(0x80059a,2)
#define		PIN_PD2_OE_CLR		IO_BIT_SET(0x80059a,2)
#define		PIN_PD2_DS_SET		IO_BIT_SET(0x800599,2)
#define		PIN_PD2_DS_CLR		IO_BIT_CLR(0x800599,2)
#define		PIN_PD2_DS_SET		IO_BIT_SET(0x80059d,2)
#define		PIN_PD2_DS_CLR		IO_BIT_CLR(0x80059d,2)
#define		PIN_PD2_OUT_H		IO_BIT_SET(0x80059b,2)
#define		PIN_PD2_OUT_L		IO_BIT_CLR(0x80059b,2)
#define		PIN_PD2_INPUT		IO_BIT_VALUE(0x800598,2)


//-------------- pin PD3---------------------------//
#define		PIN_PD3_AS_GPIO		IO_BIT_SET(0x80059e,3)
#define		PIN_PD3_OE_SET		IO_BIT_CLR(0x80059a,3)
#define		PIN_PD3_OE_CLR		IO_BIT_SET(0x80059a,3)
#define		PIN_PD3_DS_SET		IO_BIT_SET(0x800599,3)
#define		PIN_PD3_DS_CLR		IO_BIT_CLR(0x800599,3)
#define		PIN_PD3_DS_SET		IO_BIT_SET(0x80059d,3)
#define		PIN_PD3_DS_CLR		IO_BIT_CLR(0x80059d,3)
#define		PIN_PD3_OUT_H		IO_BIT_SET(0x80059b,3)
#define		PIN_PD3_OUT_L		IO_BIT_CLR(0x80059b,3)
#define		PIN_PD3_INPUT		IO_BIT_VALUE(0x800598,3)


//-------------- pin PD4---------------------------//
#define		PIN_PD4_AS_GPIO		IO_BIT_SET(0x80059e,4)
#define		PIN_PD4_OE_SET		IO_BIT_CLR(0x80059a,4)
#define		PIN_PD4_OE_CLR		IO_BIT_SET(0x80059a,4)
#define		PIN_PD4_DS_SET		IO_BIT_SET(0x800599,4)
#define		PIN_PD4_DS_CLR		IO_BIT_CLR(0x800599,4)
#define		PIN_PD4_DS_SET		IO_BIT_SET(0x80059d,4)
#define		PIN_PD4_DS_CLR		IO_BIT_CLR(0x80059d,4)
#define		PIN_PD4_OUT_H		IO_BIT_SET(0x80059b,4)
#define		PIN_PD4_OUT_L		IO_BIT_CLR(0x80059b,4)
#define		PIN_PD4_INPUT		IO_BIT_VALUE(0x800598,4)


//-------------- pin PD5---------------------------//
#define		PIN_PD5_AS_GPIO		IO_BIT_SET(0x80059e,5)
#define		PIN_PD5_OE_SET		IO_BIT_CLR(0x80059a,5)
#define		PIN_PD5_OE_CLR		IO_BIT_SET(0x80059a,5)
#define		PIN_PD5_DS_SET		IO_BIT_SET(0x800599,5)
#define		PIN_PD5_DS_CLR		IO_BIT_CLR(0x800599,5)
#define		PIN_PD5_DS_SET		IO_BIT_SET(0x80059d,5)
#define		PIN_PD5_DS_CLR		IO_BIT_CLR(0x80059d,5)
#define		PIN_PD5_OUT_H		IO_BIT_SET(0x80059b,5)
#define		PIN_PD5_OUT_L		IO_BIT_CLR(0x80059b,5)
#define		PIN_PD5_INPUT		IO_BIT_VALUE(0x800598,5)


//-------------- pin PD6---------------------------//
#define		PIN_PD6_AS_GPIO		IO_BIT_SET(0x80059e,6)
#define		PIN_PD6_OE_SET		IO_BIT_CLR(0x80059a,6)
#define		PIN_PD6_OE_CLR		IO_BIT_SET(0x80059a,6)
#define		PIN_PD6_DS_SET		IO_BIT_SET(0x800599,6)
#define		PIN_PD6_DS_CLR		IO_BIT_CLR(0x800599,6)
#define		PIN_PD6_DS_SET		IO_BIT_SET(0x80059d,6)
#define		PIN_PD6_DS_CLR		IO_BIT_CLR(0x80059d,6)
#define		PIN_PD6_OUT_H		IO_BIT_SET(0x80059b,6)
#define		PIN_PD6_OUT_L		IO_BIT_CLR(0x80059b,6)
#define		PIN_PD6_INPUT		IO_BIT_VALUE(0x800598,6)


//-------------- pin PD7---------------------------//
#define		PIN_PD7_AS_GPIO		IO_BIT_SET(0x80059e,7)
#define		PIN_PD7_OE_SET		IO_BIT_CLR(0x80059a,7)
#define		PIN_PD7_OE_CLR		IO_BIT_SET(0x80059a,7)
#define		PIN_PD7_DS_SET		IO_BIT_SET(0x800599,7)
#define		PIN_PD7_DS_CLR		IO_BIT_CLR(0x800599,7)
#define		PIN_PD7_DS_SET		IO_BIT_SET(0x80059d,7)
#define		PIN_PD7_DS_CLR		IO_BIT_CLR(0x80059d,7)
#define		PIN_PD7_OUT_H		IO_BIT_SET(0x80059b,7)
#define		PIN_PD7_OUT_L		IO_BIT_CLR(0x80059b,7)
#define		PIN_PD7_INPUT		IO_BIT_VALUE(0x800598,7)


//-------------- pin PE0---------------------------//
#define		PIN_PE0_AS_GPIO		IO_BIT_SET(0x8005a6,0)
#define		PIN_PE0_OE_SET		IO_BIT_CLR(0x8005a2,0)
#define		PIN_PE0_OE_CLR		IO_BIT_SET(0x8005a2,0)
#define		PIN_PE0_DS_SET		IO_BIT_SET(0x8005a1,0)
#define		PIN_PE0_DS_CLR		IO_BIT_CLR(0x8005a1,0)
#define		PIN_PE0_DS_SET		IO_BIT_SET(0x8005a5,0)
#define		PIN_PE0_DS_CLR		IO_BIT_CLR(0x8005a5,0)
#define		PIN_PE0_OUT_H		IO_BIT_SET(0x8005a3,0)
#define		PIN_PE0_OUT_L		IO_BIT_CLR(0x8005a3,0)
#define		PIN_PE0_INPUT		IO_BIT_VALUE(0x8005a0,0)


//-------------- pin PE1---------------------------//
#define		PIN_PE1_AS_GPIO		IO_BIT_SET(0x8005a6,1)
#define		PIN_PE1_OE_SET		IO_BIT_CLR(0x8005a2,1)
#define		PIN_PE1_OE_CLR		IO_BIT_SET(0x8005a2,1)
#define		PIN_PE1_DS_SET		IO_BIT_SET(0x8005a1,1)
#define		PIN_PE1_DS_CLR		IO_BIT_CLR(0x8005a1,1)
#define		PIN_PE1_DS_SET		IO_BIT_SET(0x8005a5,1)
#define		PIN_PE1_DS_CLR		IO_BIT_CLR(0x8005a5,1)
#define		PIN_PE1_OUT_H		IO_BIT_SET(0x8005a3,1)
#define		PIN_PE1_OUT_L		IO_BIT_CLR(0x8005a3,1)
#define		PIN_PE1_INPUT		IO_BIT_VALUE(0x8005a0,1)


//-------------- pin PE2---------------------------//
#define		PIN_PE2_AS_GPIO		IO_BIT_SET(0x8005a6,2)
#define		PIN_PE2_OE_SET		IO_BIT_CLR(0x8005a2,2)
#define		PIN_PE2_OE_CLR		IO_BIT_SET(0x8005a2,2)
#define		PIN_PE2_DS_SET		IO_BIT_SET(0x8005a1,2)
#define		PIN_PE2_DS_CLR		IO_BIT_CLR(0x8005a1,2)
#define		PIN_PE2_DS_SET		IO_BIT_SET(0x8005a5,2)
#define		PIN_PE2_DS_CLR		IO_BIT_CLR(0x8005a5,2)
#define		PIN_PE2_OUT_H		IO_BIT_SET(0x8005a3,2)
#define		PIN_PE2_OUT_L		IO_BIT_CLR(0x8005a3,2)
#define		PIN_PE2_INPUT		IO_BIT_VALUE(0x8005a0,2)


//-------------- pin PE3---------------------------//
#define		PIN_PE3_AS_GPIO		IO_BIT_SET(0x8005a6,3)
#define		PIN_PE3_OE_SET		IO_BIT_CLR(0x8005a2,3)
#define		PIN_PE3_OE_CLR		IO_BIT_SET(0x8005a2,3)
#define		PIN_PE3_DS_SET		IO_BIT_SET(0x8005a1,3)
#define		PIN_PE3_DS_CLR		IO_BIT_CLR(0x8005a1,3)
#define		PIN_PE3_DS_SET		IO_BIT_SET(0x8005a5,3)
#define		PIN_PE3_DS_CLR		IO_BIT_CLR(0x8005a5,3)
#define		PIN_PE3_OUT_H		IO_BIT_SET(0x8005a3,3)
#define		PIN_PE3_OUT_L		IO_BIT_CLR(0x8005a3,3)
#define		PIN_PE3_INPUT		IO_BIT_VALUE(0x8005a0,3)


//-------------- pin PE4---------------------------//
#define		PIN_PE4_AS_GPIO		IO_BIT_SET(0x8005a6,4)
#define		PIN_PE4_OE_SET		IO_BIT_CLR(0x8005a2,4)
#define		PIN_PE4_OE_CLR		IO_BIT_SET(0x8005a2,4)
#define		PIN_PE4_DS_SET		IO_BIT_SET(0x8005a1,4)
#define		PIN_PE4_DS_CLR		IO_BIT_CLR(0x8005a1,4)
#define		PIN_PE4_DS_SET		IO_BIT_SET(0x8005a5,4)
#define		PIN_PE4_DS_CLR		IO_BIT_CLR(0x8005a5,4)
#define		PIN_PE4_OUT_H		IO_BIT_SET(0x8005a3,4)
#define		PIN_PE4_OUT_L		IO_BIT_CLR(0x8005a3,4)
#define		PIN_PE4_INPUT		IO_BIT_VALUE(0x8005a0,4)


//-------------- pin PE5---------------------------//
#define		PIN_PE5_AS_GPIO		IO_BIT_SET(0x8005a6,5)
#define		PIN_PE5_OE_SET		IO_BIT_CLR(0x8005a2,5)
#define		PIN_PE5_OE_CLR		IO_BIT_SET(0x8005a2,5)
#define		PIN_PE5_DS_SET		IO_BIT_SET(0x8005a1,5)
#define		PIN_PE5_DS_CLR		IO_BIT_CLR(0x8005a1,5)
#define		PIN_PE5_DS_SET		IO_BIT_SET(0x8005a5,5)
#define		PIN_PE5_DS_CLR		IO_BIT_CLR(0x8005a5,5)
#define		PIN_PE5_OUT_H		IO_BIT_SET(0x8005a3,5)
#define		PIN_PE5_OUT_L		IO_BIT_CLR(0x8005a3,5)
#define		PIN_PE5_INPUT		IO_BIT_VALUE(0x8005a0,5)


//-------------- pin PE6---------------------------//
#define		PIN_PE6_AS_GPIO		IO_BIT_SET(0x8005a6,6)
#define		PIN_PE6_AS_CN		IO_BIT_CLR(0x8005a6,6);IO_BIT_CLR(0x8005b4,6);IO_BIT_CLR(0x8005b6,5)
#define		PIN_PE6_OE_SET		IO_BIT_CLR(0x8005a2,6)
#define		PIN_PE6_OE_CLR		IO_BIT_SET(0x8005a2,6)
#define		PIN_PE6_DS_SET		IO_BIT_SET(0x8005a1,6)
#define		PIN_PE6_DS_CLR		IO_BIT_CLR(0x8005a1,6)
#define		PIN_PE6_DS_SET		IO_BIT_SET(0x8005a5,6)
#define		PIN_PE6_DS_CLR		IO_BIT_CLR(0x8005a5,6)
#define		PIN_PE6_OUT_H		IO_BIT_SET(0x8005a3,6)
#define		PIN_PE6_OUT_L		IO_BIT_CLR(0x8005a3,6)
#define		PIN_PE6_INPUT		IO_BIT_VALUE(0x8005a0,6)


//-------------- pin PE7---------------------------//
#define		PIN_PE7_AS_GPIO		IO_BIT_SET(0x8005a6,7)
#define		PIN_PE7_OE_SET		IO_BIT_CLR(0x8005a2,7)
#define		PIN_PE7_OE_CLR		IO_BIT_SET(0x8005a2,7)
#define		PIN_PE7_DS_SET		IO_BIT_SET(0x8005a1,7)
#define		PIN_PE7_DS_CLR		IO_BIT_CLR(0x8005a1,7)
#define		PIN_PE7_DS_SET		IO_BIT_SET(0x8005a5,7)
#define		PIN_PE7_DS_CLR		IO_BIT_CLR(0x8005a5,7)
#define		PIN_PE7_OUT_H		IO_BIT_SET(0x8005a3,7)
#define		PIN_PE7_OUT_L		IO_BIT_CLR(0x8005a3,7)
#define		PIN_PE7_INPUT		IO_BIT_VALUE(0x8005a0,7)


//-------------- pin PF0---------------------------//
#define		PIN_PF0_AS_GPIO		IO_BIT_SET(0x8005ae,0)
#define		PIN_PF0_AS_DO		IO_BIT_CLR(0x8005ae,0);IO_BIT_CLR(0x8005b6,5)
#define		PIN_PF0_OE_SET		IO_BIT_CLR(0x8005aa,0)
#define		PIN_PF0_OE_CLR		IO_BIT_SET(0x8005aa,0)
#define		PIN_PF0_DS_SET		IO_BIT_SET(0x8005a9,0)
#define		PIN_PF0_DS_CLR		IO_BIT_CLR(0x8005a9,0)
#define		PIN_PF0_DS_SET		IO_BIT_SET(0x8005ad,0)
#define		PIN_PF0_DS_CLR		IO_BIT_CLR(0x8005ad,0)
#define		PIN_PF0_OUT_H		IO_BIT_SET(0x8005ab,0)
#define		PIN_PF0_OUT_L		IO_BIT_CLR(0x8005ab,0)
#define		PIN_PF0_INPUT		IO_BIT_VALUE(0x8005a8,0)


//-------------- pin PF1---------------------------//
#define		PIN_PF1_AS_GPIO		IO_BIT_SET(0x8005ae,1)
#define		PIN_PF1_AS_CK		IO_BIT_CLR(0x8005ae,1)
#define		PIN_PF1_OE_SET		IO_BIT_CLR(0x8005aa,1)
#define		PIN_PF1_OE_CLR		IO_BIT_SET(0x8005aa,1)
#define		PIN_PF1_DS_SET		IO_BIT_SET(0x8005a9,1)
#define		PIN_PF1_DS_CLR		IO_BIT_CLR(0x8005a9,1)
#define		PIN_PF1_DS_SET		IO_BIT_SET(0x8005ad,1)
#define		PIN_PF1_DS_CLR		IO_BIT_CLR(0x8005ad,1)
#define		PIN_PF1_OUT_H		IO_BIT_SET(0x8005ab,1)
#define		PIN_PF1_OUT_L		IO_BIT_CLR(0x8005ab,1)
#define		PIN_PF1_INPUT		IO_BIT_VALUE(0x8005a8,1)

///////////////////////// the user interface //////////////////////////////////

#define		gpio_func_set(name,function)		PIN_##name##_AS_##function
#define		gpio_oe_set(name)					PIN_##name##_OE_SET
#define		gpio_oe_clr(name)					PIN_##name##_OE_CLR
#define		gpio_ie_set(name)					PIN_##name##_IE_SET
#define		gpio_ie_clr(name)					PIN_##name##_IE_CLR
#define		gpio_ds_set(name)					PIN_##name##_DS_SET
#define		gpio_ds_clr(name)					PIN_##name##_DS_CLR
#define		gpio_out_high(name)					PIN_##name##_OUT_H
#define		gpio_out_low(name)					PIN_##name##_OUT_L
#define		gpio_input(name)					PIN_##name##_INPUT



#define		gpio_init()			do{\
				write_reg8(0x8005b4,read_reg8(0x8005b4)|(RIO_05b4_6<<6));\
				write_reg8(0x8005b6,read_reg8(0x8005b6)|(RIO_05b6_5<<5));\
}while(0)

#endif
