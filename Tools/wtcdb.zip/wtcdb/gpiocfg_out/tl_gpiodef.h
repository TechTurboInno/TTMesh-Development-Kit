/*
* tl_gpiodef.h
*
* create on: Tue Nov 29 19:08:56 2016

* Author:gpiocfg tools
*
*/
#ifndef TL_GPIODEF_H_
#define TL_GPIODEF_H_


#define		ENABLE				1
#define		DISABLE				0
#define		PIN_ERROR 			0xff
#define		NDF	 				0xff
#define		AS_GPIO				0
#define		AS_F_1				1
#define		AS_F_2				2
#define		AS_F_3				3
#define		AS_F_4				4


#define		PA0_AS_GPIO			AS_F_0
#define		PA0_AS_SWS			AS_F_1
#define		PA1_AS_GPIO			AS_F_0
#define		PA2_AS_GPIO			AS_F_0
#define		PA2_AS_MSDI			AS_F_1
#define		PA3_AS_GPIO			AS_F_0
#define		PA3_AS_MCLK			AS_F_1
#define		PA4_AS_GPIO			AS_F_0
#define		PA5_AS_GPIO			AS_F_0
#define		PA6_AS_GPIO			AS_F_0
#define		PA7_AS_GPIO			AS_F_0
#define		PB0_AS_GPIO			AS_F_0
#define		PB1_AS_GPIO			AS_F_0
#define		PB2_AS_GPIO			AS_F_0
#define		PB2_AS_MSDO			AS_F_1
#define		PB3_AS_GPIO			AS_F_0
#define		PB3_AS_MSCN			AS_F_1
#define		PB4_AS_GPIO			AS_F_0
#define		PB5_AS_GPIO			AS_F_0
#define		PB5_AS_DM			AS_F_1
#define		PB6_AS_GPIO			AS_F_0
#define		PB6_AS_DP			AS_F_1
#define		PB7_AS_GPIO			AS_F_0
#define		PC0_AS_GPIO			AS_F_0
#define		PC1_AS_GPIO			AS_F_0
#define		PC2_AS_GPIO			AS_F_0
#define		PC3_AS_GPIO			AS_F_0
#define		PC4_AS_GPIO			AS_F_0
#define		PC5_AS_GPIO			AS_F_0
#define		PC6_AS_GPIO			AS_F_0
#define		PC7_AS_GPIO			AS_F_0
#define		PD0_AS_GPIO			AS_F_0
#define		PD1_AS_GPIO			AS_F_0
#define		PD2_AS_GPIO			AS_F_0
#define		PD3_AS_GPIO			AS_F_0
#define		PD4_AS_GPIO			AS_F_0
#define		PD5_AS_GPIO			AS_F_0
#define		PD6_AS_GPIO			AS_F_0
#define		PD7_AS_GPIO			AS_F_0
#define		PE0_AS_GPIO			AS_F_0
#define		PE1_AS_GPIO			AS_F_0
#define		PE2_AS_GPIO			AS_F_0
#define		PE3_AS_GPIO			AS_F_0
#define		PE4_AS_GPIO			AS_F_0
#define		PE5_AS_GPIO			AS_F_0
#define		PE6_AS_GPIO			AS_F_0
#define		PE6_AS_CN			AS_F_1
#define		PE7_AS_GPIO			AS_F_0
#define		PF0_AS_GPIO			AS_F_0
#define		PF0_AS_DO			AS_F_1
#define		PF1_AS_GPIO			AS_F_0
#define		PF1_AS_CK			AS_F_1
#endif
